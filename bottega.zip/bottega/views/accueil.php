
<div class="accueil d-flex justify-content-center text-ocean py-5">
<!-- on utilise un attribut data de données pour stocker des informations supplémentaires et pour les voir on utilise javascript -->
    <h1 id="hello" data-label="Sans parfum la peau est muette."></h1>
        <a class="nav-link" href="<?= URL ?>boutique"><h5 class="fst-italic text-decoration-underline text-ocean">Découvrir ici nos articles! </h5></a>

</div>   
<div class="d-flex justify-content-center text-ocean">  
            <div class="card shadow-sm my-3"><h2>NOS PROMESSES</h2></div>
</div> 
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3 d-flex justify-content-center">  
                <span class="card shadow-sm mx-1 text-ocean text-center"><strong>Qualité haut de gamme</strong> Collaborant avec des fournisseurs de renommée, Parfums de rêve met à votre disposition des produits de qualité.</span>
                <span class="card shadow-sm mx-1 text-ocean text-center"><strong>Diversité de choix</strong> Disposant d'une longue liste de produits, Parfums de rêve est aujourd'hui capable de satisfaire tous les goûts.</span>
                <span class="card shadow-sm mx-1 text-ocean text-center"><strong>Prix alléchant</strong> Proposant des prix à la portée du budget, Parfums de rêve aide ses clients à acheter sans contraintes.</span>
                <span class="card shadow-sm mx-1 text-ocean text-center"><strong>Livraison rapide</strong> Fidèles à nos objectifs d’excellence, la rapidité de livraison de nos produits est incroyable.</span>
            </div>

</div>    




<script src="<?= SCRIPTS . 'javascript' . DIRECTORY_SEPARATOR . 'index.js' ?>"></script>
