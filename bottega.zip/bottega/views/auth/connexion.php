<h1 class="d-flex justify-content-center text-primary my-5">Page de Connexion</h1>

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
<div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
     <?= $_SESSION['success'] ?> 
 </div>


 <?php unset($_SESSION['success']); ?>
<?php endif ?>

<?php if(isset($_SESSION['erreur']) && !empty($_SESSION['erreur'])) :?>
 
 <div class="alert alert-danger d-flex justify-content-center my-5" role="alert">
      <?= $_SESSION['erreur'] ?> 
  </div>
 
 
  <?php unset($_SESSION['erreur']); ?>
 <?php endif ?>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert"> 
        <form action="<?= URL ?>monCompte" class="w-50" method="POST"> 
    
            <div class="form-group my-3">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" class="form-control"  required>
            <!-- message d'erreur--> 
            </div>
            <div class="form-group my-3">
                <label for="motdepasse">Mot de passe</label>
                <input type="password" name="motdepasse" id="motdepasse" class="form-control" required>
            
            </div>
            
            <div class="form-group my-3 text-center">
                <input type="submit"  class="btn btn-secondary" value="Se connecter" /> 
            </div>

            <div class="form-group my-3 text-center">
                <p>Vous n'avez pas de compte?<a href="<?= URL ?>inscription"> S'inscrire ici</a>
            </div>
        </form>
    </div>
</div>