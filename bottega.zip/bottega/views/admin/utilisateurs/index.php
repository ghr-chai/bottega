<h1 class="d-flex justify-content-center text-primary my-3">Administration des utilisateurs</h1>

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <?= $_SESSION['success'] ?> 
    </div>


    <?php unset($_SESSION['success']); ?>
<?php endif ?>

<div class="d-flex justify-content-end align-items-center my-3">
    <a class="btn btn-primary" href="<?= URL ?>admin/utilisateurs/create">Ajouter utilisateur</a>
</div>
<div class="d-flex justify-content-end align-items-center my-3">
        <a href="<?= URL ?>espaceReserve" class="btn btn-secondary" >Retourner en arrière</a>
</div>

<?php if(isset($params['utilisateurs']) && !empty($params['utilisateurs'])) : ?>
    <div class="table-responsive">
        <table class="text-center table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Adresse</th>
                    <th>Tél</th>
                    <th>Email</th>
                    <th>Mot de Passe</th>
                    <th>Type</th>
                    <th>Date Création</th>
                    <!-- <th>Date Modification</th> -->
                    <th>Manager</th>
                    <th>Rôle</th>
                    <th>Paramètres</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($params['utilisateurs'] as $utilisateur) : ?>
                    <!--<?php Var_dump($params['utilisateurs']); ?>-->
                    <tr>
                        <td><?= $utilisateur->id ?></td>
                        <td><?= $utilisateur->nom?></td>
                        <td><?= $utilisateur->prenom?></td>
                        <td><?= $utilisateur->adresse ?></td>
                        <td><?= $utilisateur->tel?></td>
                        <td><?= $utilisateur->email ?></td>
                        <td><?= $utilisateur->motdepasse ?></td>
                        <td><?= $utilisateur->type ?></td>
                        <td><?= $utilisateur->datecreation ?></td>
                         <!-- <td><?= $utilisateur->datemodification ?></td> -->
                         <td><?php $data = $utilisateur->getNomUtilisateur($utilisateur->id); echo $data->nom; ?></td>    
                         <td><?php $data = $utilisateur->getRole($utilisateur->id); echo $data->libellerole; ?></td>
                        <td>
                            <a href="<?= URL ?>admin/utilisateurs/edit/<?= $utilisateur->id ?>" class="btn btn-secondary">Modifier</a>
                            <form action="<?= URL ?>admin/utilisateurs/delete/<?=$utilisateur->id?>" method="POST" class="d-inline">
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <h2 class="text-center my-5">
        Aucun utilisateur ajouté pour le moment
    </h2>
<?php endif ?>
