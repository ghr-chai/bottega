<h1 class="d-flex justify-content-center text-primary my-3">Modifier utilisateur</h1>

<div class="container"> 
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/utilisateurs/edit/<?= $params['utilisateur']->id ?>" class="w-50" method="POST"> 

            <div class="form-group my-3">
                <label for="nom">Nom:</label>
                <input type="text" id="nom" name="nom" class="form-control" value="<?= $params['utilisateur']->nom ?>" required />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['nom']) && !empty($_SESSION['errors']['nom']) ) : ?>
                    <?php foreach($_SESSION['errors']['nom'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['nom']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="prenom">Prénom:</label>
                <input type="text" id="prenom" name="prenom" class="form-control" value="<?= $params['utilisateur']->prenom ?>" required />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['prenom']) && !empty($_SESSION['errors']['prenom']) ) : ?>
                    <?php foreach($_SESSION['errors']['prenom'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['prenom']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="adresse">Adresse:</label>
                <input type="text" id="adresse" name="adresse" class="form-control" value="<?= $params['utilisateur']->adresse ?>" required/>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['adresse']) && !empty($_SESSION['errors']['adresse']) ) : ?>
                    <?php foreach($_SESSION['errors']['adresse'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['adresse']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
                <label for="tel">Tél:</label>
                <input type="tel" id="tel" name="tel" class="form-control" value="<?= $params['utilisateur']->tel ?>" required/>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['tel']) && !empty($_SESSION['errors']['tel']) ) : ?>
                    <?php foreach($_SESSION['errors']['tel'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['tel']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" class="form-control" value="<?= $params['utilisateur']->email ?>" required />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['email']) && !empty($_SESSION['errors']['email']) ) : ?>
                    <?php foreach($_SESSION['errors']['email'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['email']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
                <label for="motdepasse">Mot de Passe:</label>
                <input type="password" id="motdepasse" name="motdepasse" class="form-control" value="<?= $params['utilisateur']->motdepasse ?>" required />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['motdepasse']) && !empty($_SESSION['errors']['motdepasse']) ) : ?>
                    <?php foreach($_SESSION['errors']['motdepasse'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['motdepasse']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
            <label for="type">Type</label>
                    <select name="type" class="form-control">

                        <?php foreach ($params['utilisateurs'] as $utilisateur) : ?>
                                <option value="<?=  $utilisateur->id ?>"> <?= $params['utilisateur']->type ?> </option>
                        <?php endforeach ?>
    
                    </select>
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['type']) && !empty($_SESSION['errors']['type']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['type'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['type']); ?>
                <?php endif ?>
            </div>
            
            <div class="form-group my-3">
                <label for="idutilisateur">Utilisateur</label>
                    <select name="idutilisateur" id="idutilisateur" class="form-control">       
                    <?php foreach ($params['utilisateurs'] as $utilisateur) : ?>
                            <option value="<?=  $utilisateur->id ?>"  <?= $utilisateur->id == $params['utilisateur']->idutilisateur ? 'selected' : ' ' ?>> <?php if($utilisateur->type === "utilisateur") : ?> <?= $utilisateur->prenom?>
                                <?php else : ?>
                                        <?= "" ?></option>
                                <?php endif ?>         </option>
                    <?php endforeach ?>
                    </select>
                    <!-- Affichage d'erreur  -->
                    <?php if(isset($_SESSION['errors']['idutilisateur']) && !empty($_SESSION['errors']['idutilisateur']) ) : ?>
                        <?php foreach($_SESSION['errors']['idutilisateur'] as $error) : ?> 
                            <div class="text-danger">
                                <?= $error ?>
                                <?php break; ?>
                            </div>
                        <?php endforeach ?>
                        <?php unset($_SESSION['errors']['idutilisateur']); ?>
                    <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="idrole">Rôle</label>
                    <select name="idrole" id="idrole" class="form-control">  
                        <?php foreach ($params['roles'] as $role) : ?>
                                <option value="<?=  $role->id ?>"  <?= $role->id == $params['utilisateur']->idrole ? 'selected' : ' ' ?>> <?= $role->libellerole ?> </option>
                        <?php endforeach ?>
                    </select>
                    <!-- Affichage d'erreur  -->
                    <?php if(isset($_SESSION['errors']['idrole']) && !empty($_SESSION['errors']['idrole']) ) : ?>
                        <?php foreach($_SESSION['errors']['idrole'] as $error) : ?> 
                            <div class="text-danger">
                                <?= $error ?>
                                <?php break; ?>
                            </div>
                        <?php endforeach ?>
                        <?php unset($_SESSION['errors']['idrole']); ?>
                    <?php endif ?>
            </div>

            <div class="form-group my-3 text-center">
                <input type="submit" value="Modifier" class="btn btn-secondary" />
            </div>

        </form>
    </div>    
</div>
