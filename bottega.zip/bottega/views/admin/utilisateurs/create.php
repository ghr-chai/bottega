<h1 class="d-flex justify-content-center text-primary my-3">Ajouter utilisateur</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/utilisateurs/create" class="w-50" method="POST"> 

            <div class="form-group my-3">
                <label for="nom">Nom:</label>
                <input 
                    type="text" 
                    id="nom" 
                    name="nom" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['nom'] ?? ''; 
                                unset($_SESSION['previous_input']['nom']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['nom']) && !empty($_SESSION['errors']['nom']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['nom'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['nom']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="prenom">Prénom:</label>
                <input 
                    type="text" 
                    id="prenom" 
                    name="prenom" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['prenom'] ?? ''; 
                                unset($_SESSION['previous_input']['prenom']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['prenom']) && !empty($_SESSION['errors']['prenom']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['prenom'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['prenom']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="adresse">Adresse:</label>
                <input 
                    type="text" 
                    id="adresse" 
                    name="adresse" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['adresse'] ?? ''; 
                                unset($_SESSION['previous_input']['adresse']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['adresse']) && !empty($_SESSION['errors']['adresse']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['adresse'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['adresse']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="tel">Tél:</label>
                <input 
                    type="tel" 
                    id="tel" 
                    name="tel" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['tel'] ?? ''; 
                                unset($_SESSION['previous_input']['tel']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['tel']) && !empty($_SESSION['errors']['tel']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['tel'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['tel']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="email">Email:</label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['email'] ?? ''; 
                                unset($_SESSION['previous_input']['email']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['email']) && !empty($_SESSION['errors']['email']) ) : ?>
                    <?php foreach($_SESSION['errors']['email'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['email']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="motdepasse">Mot de Passe:</label>
                <input 
                    type="password" 
                    id="motdepasse" 
                    name="motdepasse" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['motdepasse'] ?? ''; 
                                unset($_SESSION['previous_input']['motdepasse']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['motdepasse']) && !empty($_SESSION['errors']['motdepasse']) ) : ?>
                    <?php foreach($_SESSION['errors']['motdepasse'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['motdepasse']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
                <label for="type">Choisissez un type:</label>
                    <select name="type" class="form-control">
                        <option selected disabled>---</option>
                        <option >Client</option>
                        <option >Utilisateur</option>
                    </select>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['type']) && !empty($_SESSION['errors']['type']) ) : ?>
                    <?php foreach($_SESSION['errors']['type'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['type']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
            <label for="idutilisateur">Choisissez un utilisateur:</label>
                    <select name="idutilisateur" class="form-control">
                            <option selected disabled>---</option>
                            <?php if(isset($params['utilisateurs']) && !empty($params['utilisateurs'])) : ?>
                                <?php foreach($params['utilisateurs'] as $utilisateur) : ?>
                                    <option value="<?= $utilisateur->id ?>">
                                    <?php if($utilisateur->type === "utilisateur") : ?>
                                        <?= $utilisateur->prenom ?></option>
                                    <?php else : ?>
                                        <?= "" ?></option>
                                    <?php endif ?>         

                                <?php endforeach ?>  
                            <?php endif ?>
                    </select>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['idutilisateur']) && !empty($_SESSION['errors']['idutilisateur']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['idutilisateur'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idutilisateur']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="idrole">Choisissez un rôle:</label>
                    <select name="idrole" class="form-control">
                            <option selected disabled>---</option>
                            <?php if(isset($params['roles']) && !empty($params['roles'])) : ?>
                                <?php foreach($params['roles'] as $role) : ?>
                                    <option value="<?= $role->id ?>"><?= $role->libellerole ?></option>
                                <?php endforeach ?> 
                            <?php endif ?>
                    </select>
                <!-- Affichage d'erreur  -->
                
                <?php if(isset($_SESSION['errors']['idrole']) && !empty($_SESSION['errors']['idrole']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['idrole'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idrole']); ?>
                <?php endif ?>
            </div> 

            <div class="form-group my-3 text-center">
                <input type="submit" class="btn btn-secondary" />
            </div>

        </form>
    </div>       
</div>

