<h1 class="d-flex justify-content-center text-primary my-3">Ajouter marque</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/marques/create" class="w-50" method="POST"> 

            <div class="form-group my-3">
                <label for="nommarque">Nom marque</label>
                <input 
                    type="text" 
                    id="nommarque" 
                    name="nommarque" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['nommarque'] ?? ''; 
                                unset($_SESSION['previous_input']['nommarque']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['nommarque']) && !empty($_SESSION['errors']['nommarque']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['nommarque'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['nommarque']); ?>
                    
                <?php endif ?>
                
            </div>

            <div class="form-group my-3 text-center">
                <input type="submit" class="btn btn-secondary" />
            </div>

        </form>
    </div>
</div>

