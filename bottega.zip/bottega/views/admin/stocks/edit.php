<h1 class="d-flex justify-content-center text-primary my-3">Modifier stock</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/stocks/edit/<?= $params['stock']->id ?>" class="w-50" method="POST"> 

            <div class="form-group my-3">
                <label for="qtestockee">Quantité Stockée:</label>
                <input type="number" id="qtestockee" name="qtestockee" class="form-control" value="<?= $params['stock']->qtestockee ?>" required/>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['qtestockee']) && !empty($_SESSION['errors']['qtestockee']) ) : ?>
                    <?php foreach($_SESSION['errors']['qtestockee'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['qtestockee']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="qtemin">Quantité Minimale:</label>
                <input type="number" id="qtemin" name="qtemin" class="form-control" value="<?= $params['stock']->qtemin ?>" required />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['qtemin']) && !empty($_SESSION['errors']['qtemin']) ) : ?>
                    <?php foreach($_SESSION['errors']['qtemin'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['qtemin']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="qtemax">Quantité Maximale:</label>
                <input type="number" id="qtemax" name="qtemax" class="form-control" value="<?= $params['stock']->qtemax ?>" required />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['qtemax']) && !empty($_SESSION['errors']['qtemax']) ) : ?>
                    <?php foreach($_SESSION['errors']['qtemax'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['qtemax']); ?>
                <?php endif ?>
            </div>
            
            <div class="form-group my-3">
            <label for="idarticle">Article</label>
                <select name="idarticle" id="idarticle" class="form-control">       
                    <?php foreach ($params['articles'] as $article) : ?>
                            <option value="<?=  $article->id ?>"  <?= $article->id == $params['stock']->idarticle ? 'selected' : ' ' ?>> <?= $article->nomarticle ?> </option>
                    <?php endforeach ?>
                </select>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['idarticle']) && !empty($_SESSION['errors']['idarticle']) ) : ?>
                    <?php foreach($_SESSION['errors']['idarticle'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idarticle']); ?>
                <?php endif ?>
            </div>
            
            <div class="form-group my-3 text-center">
                <input type="submit" value="Modifier" class="btn btn-secondary" />
            </div>

        </form>
    </div>    
</div>
