<h1 class="d-flex justify-content-center text-primary my-3">Administration des stocks</h1>

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <?= $_SESSION['success'] ?> 
    </div>


    <?php unset($_SESSION['success']); ?>
<?php endif ?>

<div class="d-flex justify-content-end align-items-center my-3">
    <a class="btn btn-primary" href="<?= URL ?>admin/stocks/create">Ajouter stock</a>
</div>
<div class="d-flex justify-content-end align-items-center my-3">
        <a href="<?= URL ?>espaceReserve" class="btn btn-secondary" >Retourner en arrière</a>
</div>

<?php if(isset($params['stocks']) && !empty($params['stocks'])) : ?>
    <div class="table-responsive">
        <table class="text-center table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Quantité Stockée</th>
                    <th>Quantité Minimale</th>
                    <th>Quantité Maximale</th>
                    <th>Article</th>
                    <th>Paramètres</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($params['stocks'] as $stock) : ?>
                    <!--<?php Var_dump($params['stocks']); ?>-->
                    <tr>
                        <td><?= $stock->id ?></td>
                        <td><?= $stock->qtestockee ?></td>
                        <td><?= $stock->qtemin ?></td>
                        <td><?= $stock->qtemax ?></td>
                        <td><?php $data = $stock->getNomArticle($stock->id); echo $data->nomarticle; ?></td>
                        <td>
                            <a href="<?= URL ?>admin/stocks/edit/<?= $stock->id ?>" class="btn btn-secondary">Modifier</a>
                            <form action="<?= URL ?>admin/stocks/delete/<?=$stock->id?>" method="POST" class="d-inline">
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <h2 class="text-center my-5">
        Aucun stock ajouté pour le moment
    </h2>
<?php endif ?>
