<h1 class="d-flex justify-content-center text-primary my-3">Modifier genre</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/genres/edit/<?= $params['genre']->id ?>" class="w-50" method="POST"> 

            <div class="form-group my-3">
                <label for="libellegenre">Genre:</label>
                <input type="text" id="libellegenre" name="libellegenre" class="form-control" value="<?= $params['genre']->libellegenre ?>" required/>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['libellegenre']) && !empty($_SESSION['errors']['libellegenre']) ) : ?>
                    <?php foreach($_SESSION['errors']['libellegenre'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['libellegenre']); ?>
                <?php endif ?>
            </div>
            
            <div class="form-group my-3 text-center">
                <input type="submit" value="Modifier" class="btn btn-secondary" />
            </div>

        </form>
    </div>
</div>
