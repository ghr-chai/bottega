<h1 class="d-flex justify-content-center text-primary my-3">Ajouter genre</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/genres/create" class="w-50" method="POST"> 

            <div class="form-group my-3">
                <label for="libellegenre">Genre:</label>
                <input 
                    type="text" 
                    id="libellegenre" 
                    name="libellegenre" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['libellegenre'] ?? ''; 
                                unset($_SESSION['previous_input']['libellegenre']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['libellegenre']) && !empty($_SESSION['errors']['libellegenre']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['libellegenre'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['libellegenre']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3 text-center">
                <input type="submit" class="btn btn-secondary />
            </div>

        </form>
    </div>
</div>

