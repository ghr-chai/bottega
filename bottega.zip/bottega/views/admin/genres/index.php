<h1 class="d-flex justify-content-center text-primary my-3">Administration des genres</h1>

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <?= $_SESSION['success'] ?> 
    </div>


    <?php unset($_SESSION['success']); ?>
<?php endif ?>

<div class="d-flex justify-content-end align-items-center my-3">
    <a class="btn btn-primary" href="<?= URL ?>admin/genres/create">Ajouter genre</a>
</div>
<div class="d-flex justify-content-end align-items-center my-3">
        <a href="<?= URL ?>espaceReserve" class="btn btn-secondary" >Retourner en arrière</a>
</div>

<?php if(isset($params['genres']) && !empty($params['genres'])) : ?>
    <div class="table-responsive">
        <table class="text-center table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Genre</th>
                    <th>Date Création</th>
                    <th>Date Modification</th>
                    <th>Paramètres</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($params['genres'] as $genre) : ?>
                    <!--<?php Var_dump($params['genres']); ?>-->
                    <tr>
                        <td><?= $genre->id ?></td>
                        <td><?= $genre->libellegenre ?></td>
                        <td><?= $genre->datecreation ?></td>
                        <td><?= $genre->datemodification ?></td>
                        <td>
                            <a href="<?= URL ?>admin/genres/edit/<?= $genre->id ?>" class="btn btn-secondary">Modifier</a>
                            <form action="<?= URL ?>admin/genres/delete/<?=$genre->id?>" method="POST" class="d-inline">
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <h2 class="text-center my-5">
        Aucun genre ajouté pour le moment
    </h2>
<?php endif ?>
