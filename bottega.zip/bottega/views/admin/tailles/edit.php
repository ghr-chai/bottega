<h1 class="d-flex justify-content-center text-primary my-3">Modifier taille</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/tailles/edit/<?= $params['taille']->id ?>" class="w-50" method="POST"> 

            <div class="form-group my-3">
                <label for="volumeflacon">Volume Flacon:</label>
                <input type="text" id="volumeflacon" name="volumeflacon" class="form-control" value="<?= $params['taille']->volumeflacon ?>" required/>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['volumeflacon']) && !empty($_SESSION['errors']['volumeflacon']) ) : ?>
                    <?php foreach($_SESSION['errors']['volumeflacon'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['volumeflacon']); ?>
                <?php endif ?>
            </div>
            
            <div class="form-group my-3 text-center">
                <input type="submit" value="Modifier" class="btn btn-secondary" />
            </div>

        </form>
    </div>
</div>
