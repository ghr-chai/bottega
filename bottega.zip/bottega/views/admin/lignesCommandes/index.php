<h1 class="d-flex justify-content-center text-primary my-3">Administration des lignes de commandes</h1>

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <?= $_SESSION['success'] ?> 
    </div>


    <?php unset($_SESSION['success']); ?>
<?php endif ?>

<div class="d-flex justify-content-end align-items-center my-3">
        <a href="<?= URL ?>espaceReserve" class="btn btn-secondary" >Retourner en arrière</a>
</div>


<?php if(isset($params['lignescommandes']) && !empty($params['lignescommandes'])) : ?>
    <div class="table-responsive">
        <table class="text-center table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Quantité</th>
                    <th>Prix €</th>
                    <th>date de création</th>
                    <th>Nom article</th>
                    <th>Id Commande</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($params['lignescommandes'] as $lignecommande) : ?>
                  
                    <tr>
                        <td><?= $lignecommande->id ?></td>
                        <td><?= $lignecommande->qtecommandee ?></td>
                        <td><p><?= $lignecommande->prixunitvente ?></p></td>
                        <td><?= $lignecommande->datecreation ?></td>
                        <td><?php $data = $lignecommande->getNomArticle($lignecommande->id); echo $data->nomarticle; ?></td>
                        <td><?= $lignecommande->idcommande ?></td>
                        <td>   
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <h2 class="text-center my-5">
        Aucune ligne de commande ajoutée pour le moment
    </h2>
<?php endif ?>