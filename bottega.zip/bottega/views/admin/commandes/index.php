<h1 class="d-flex justify-content-center text-primary my-3">Administration des commandes</h1>

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <?= $_SESSION['success'] ?> 
    </div>


    <?php unset($_SESSION['success']); ?>
<?php endif ?>

<div class="d-flex justify-content-end align-items-center my-3">
        <a href="<?= URL ?>espaceReserve" class="btn btn-secondary" >Retourner en arrière</a>
</div>


<?php if(isset($params['commandes']) && !empty($params['commandes'])) : ?>
    <div class="table-responsive">
        <table class="text-center table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Libellés commande</th>
                    <th>Adresse de la livraison</th>
                    <th>Status</th>
                    <th>Utilisateur</th>
                    <th>Date de création</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($params['commandes'] as $commande) : ?>
                  
                    <tr>
                        <td><?= $commande->id ?></td>
                        <td><?= $commande->libellecommande ?></td>
                        <td><p><?= $commande->adresselivraison ?></p></td>
                        <td><?= $commande->status ?></td>
                        <td><?php $data = $commande->getNomClient($commande->id); echo $data->client; ?></td>
                        <td><?= $commande->datecreation ?></td>
                        <td>   
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <h2 class="text-center my-5">
        Aucune commande ajouté pour le moment
    </h2>
<?php endif ?>