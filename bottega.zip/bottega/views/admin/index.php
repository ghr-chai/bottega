<h1 class="d-flex justify-content-center text-primary my-3">Page Administration</h1>

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <?= $_SESSION['success'] ?> 
    </div>


 <?php unset($_SESSION['success']); ?>
<?php endif ?>

<div class="row" style="margin: 0px;">
    <div class="sidebar  col-md-2 bg-ocean">
    <!-- le composant list-group flexible et puissant pour afficher une série de contenus. -->
        <div class="list-group list-group-flush bg-ocean text-center"> 
            <a href="<?= URL ?>espaceReserve" class="list-group-item list-group-item-action bg-ocean text-ocean">Accueil</a>
            <a href="<?= URL ?>admin/roles" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Rôles</a>
            <a href="<?= URL ?>admin/genres" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Genres</a>
            <a href="<?= URL ?>admin/stocks" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Stocks</a>
            <a href="<?= URL ?>admin/tailles" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Tailles</a>
            <a href="<?= URL ?>admin/marques" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Marques</a>
            <a href="<?= URL ?>admin/articles" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Articles</a>
            <a href="<?= URL ?>admin/utilisateurs" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Utilisateurs</a>
            <a href="<?= URL ?>admin/commandes" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Commandes</a>
            <a href="<?= URL ?>admin/lignesCommandes" class="list-group-item list-group-item-action bg-ocean text-text-ocean">Lignes de Commandes</a>
        </div>
    </div>
    
</div>