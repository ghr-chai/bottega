
<h1 class="d-flex justify-content-center text-primary my-3">Ajouter article</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">   
        <form action="<?= URL ?>admin/articles/create" class="w-50" method="POST" enctype="multipart/form-data"> 

            <div class="form-group my-3">
                <label for="nomarticle">Nom Article:</label>
                <input 
                    type="text" 
                    id="nomarticle" 
                    name="nomarticle" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['nomarticle'] ?? ''; 
                                unset($_SESSION['previous_input']['nomarticle']); 
                            ?>" 
                />
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['nomarticle']) && !empty($_SESSION['errors']['nomarticle']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['nomarticle'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['nomarticle']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="description">Description</label>
                <textarea name="description" id="description" class="form-control" rows="6"><?php 
                                echo $_SESSION['previous_input']['description'] ?? ''; 
                                unset($_SESSION['previous_input']['description']); 
                            ?></textarea>
                <?php if(isset($_SESSION['errors']['description']) && !empty($_SESSION['errors']['description']) ) : ?>
                    <?php foreach($_SESSION['errors']['description'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['description']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="imagechemin">Image:</label>
                <input 
                    type="file" 
                    id="imagechemin" 
                    name="imagechemin" 
                    class="form-control-file" 
                    
                />
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['imagechemin']) && !empty($_SESSION['errors']['imagechemin']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['imagechemin'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['imagechemin']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="prix">Prix en €</label>
                <input 
                    type="number" 
                    id="prix" 
                    name="prix" 
                    class="form-control" 
                    value="<?php
                                echo $_SESSION['previous_input']['prix'] ?? ''; 
                                unset($_SESSION['previous_input']['prix']); 
                            ?>" required
                />
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['prix']) && !empty($_SESSION['errors']['prix']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['prix'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['prix']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
                <label for="idmarque">Choisissez une marque:</label>
                    <select name="idmarque" class="form-control">
                            <option selected disabled>---</option>
                            <?php if(isset($params['marques']) && !empty($params['marques'])) : ?>
                                <?php foreach($params['marques'] as $marque) : ?>
                                    <option value="<?= $marque->id ?>"><?= $marque->nommarque ?></option>
                                <?php endforeach ?> 
                            <?php endif ?>
                    </select>
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['idmarque']) && !empty($_SESSION['errors']['idmarque']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['idmarque'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idmarque']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
            <label for="idutilisateur">Choisissez un utilisateur interne:</label>
                    <select name="idutilisateur" class="form-control">
                            <option selected disabled>---</option>
                            <?php if(isset($params['utilisateurs']) && !empty($params['utilisateurs'])) : ?>
                                <?php foreach($params['utilisateurs'] as $utilisateur) : ?>
                                    <option value="<?= $utilisateur->id ?>">
                                    <?php if($utilisateur->type === "utilisateur") : ?>
                                        <?= $utilisateur->prenom ?></option>
                                    <?php else : ?>
                                        <?= "" ?></option>
                                    <?php endif ?>         

                                <?php endforeach ?> 
                            <?php endif ?>
                    </select>
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['idutilisateur']) && !empty($_SESSION['errors']['idutilisateur']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['idutilisateur'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idutilisateur']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
            <label for="idtaille">Choisissez la taille du flacon:</label>
                    <select name="idtaille" class="form-control">
                            <option selected disabled>---</option>
                            <?php if(isset($params['tailles']) && !empty($params['tailles'])) : ?>
                                <?php foreach($params['tailles'] as $taille) : ?>
                                    <option value="<?= $taille->id ?>"><?= $taille->volumeflacon ?></option>
                                <?php endforeach ?> 
                            <?php endif ?>
                    </select>
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['idtaille']) && !empty($_SESSION['errors']['idtaille']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['idtaille'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idtaille']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
            <label for="idgenre">Choisissez le genre:</label>
                    <select name="idgenre" class="form-control">
                            <option selected disabled>---</option>
                            <?php if(isset($params['genres']) && !empty($params['genres'])) : ?>
                                <?php foreach($params['genres'] as $genre) : ?>
                                    <option value="<?= $genre->id ?>"><?= $genre->libellegenre ?></option>
                                <?php endforeach ?> 
                            <?php endif ?>
                    </select>
                <!-- Affichage d'erreur  -->
                <?php
                
                    if(isset($_SESSION['errors']['idgenre']) && !empty($_SESSION['errors']['idgenre']) ) : ?>
                    <?php
                        foreach($_SESSION['errors']['idgenre'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idgenre']); ?>
                <?php endif ?>
            </div>
            
            <div class="form-group my-3 text-center">
                <input type="submit" class="btn btn-secondary" />
            </div>

        </form>
    </div>    
</div>

