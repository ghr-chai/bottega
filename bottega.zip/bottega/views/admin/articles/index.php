
<h1 class="d-flex justify-content-center text-primary my-3">Administration des articles</h1>

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <?= $_SESSION['success'] ?> 
    </div>


    <?php unset($_SESSION['success']); ?>
<?php endif ?>

<div class="d-flex justify-content-end align-items-center my-3">
    <a class="btn btn-primary" href="<?= URL ?>admin/articles/create">Ajouter article</a>
</div>
<div class="d-flex justify-content-end align-items-center my-3">
        <a href="<?= URL ?>espaceReserve" class="btn btn-secondary" >Retourner en arrière</a>
</div>


<?php if(isset($params['articles']) && !empty($params['articles'])) : ?>
    <div class="table-responsive">
        <table class="text-center table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nom article</th>
                    <th>Image</th>
                    <th>Description</th>
                    <th>Prix€ </th>
                    <!-- <th>Date création</th>
                    <th>Date modification</th> -->
                    <th>Marque</th>
                    <th>Taille</th>
                    <th>Genre</th>
                    <!-- <th>Utilisateur interne</th> -->
                    <th>Paramètres</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($params['articles'] as $article) : ?>
                    <!--<?php Var_dump($params['articles']); ?>-->
                    <tr>
                        <td><?= $article->id ?></td>
                        <td><?= $article->nomarticle ?></td>
                        <td><img src="<?=$article->imagechemin?>" width="100" height="100" alt="parfum"></td>
                        <td><p><?= $article->description ?></p></td>
                        <td><?= $article->prix ?></td>
                        <!-- <td><?= $article->datecreation ?></td>
                        <td><?= $article->datemodification ?></td> -->
                        <td><?php $data = $article->getNomMarque($article->id); echo $data->nommarque; ?></td>
                        <td><?php $data = $article->getVolumeFlacon($article->id); echo $data->volumeflacon; ?></td>
                        <td><?php $data = $article->getGenre($article->id); echo $data->libellegenre; ?></td>
                        <!-- <td><?php $data = $article->getNomUtilisateur($article->id); echo $data->prenom; ?></td> -->
                        <td>
                            <a href="<?= URL ?>admin/articles/edit/<?= $article->id ?>" class="btn btn-secondary">Modifier</a>
                            <form action="<?= URL ?>admin/articles/delete/<?=$article->id?>" method="POST" class="d-inline">
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <h2 class="text-center my-5">
        Aucun article ajouté pour le moment
    </h2>
<?php endif ?>

