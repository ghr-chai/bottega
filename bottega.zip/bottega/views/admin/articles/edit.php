
<h1 class="d-flex justify-content-center text-primary my-3">Modifier article</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/articles/edit/<?= $params['article']->id ?>" class="w-50" method="POST" enctype="multipart/form-data"> 

            <div class="form-group my-3">
                <label for="nomarticle">Nom article:</label>
                <input type="text" id="nomarticle" name="nomarticle" class="form-control" value="<?= $params['article']->nomarticle ?>" required />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['nomarticle']) && !empty($_SESSION['errors']['nomarticle']) ) : ?>
                    <?php foreach($_SESSION['errors']['nomarticle'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['nomarticle']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
                <label for="description">Description</label>
                <textarea name="description" id="description" class="form-control" rows="6"><?= 
                                $params['article']->description;
                            ?></textarea>
                <?php if(isset($_SESSION['errors']['description']) && !empty($_SESSION['errors']['description']) ) : ?>
                    <?php foreach($_SESSION['errors']['description'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['description']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
                <div class="d-flex justify-content-around align-items-center">
                    <div>
                        <p>Image Actuelle</p>
                        <img src="<?= $params['article']->imagechemin ?>" width="100" height="100" alt="parfum">
                    </div>
                    <label for="imagechemin">Image:</label>
                    <input type="file" id="imagechemin" name="imagechemin" class="form-control-file"  />
                    <!-- Affichage d'erreur  -->
                    <?php if(isset($_SESSION['errors']['imagechemin']) && !empty($_SESSION['errors']['imagechemin']) ) : ?>
                        <?php foreach($_SESSION['errors']['imagechemin'] as $error) : ?> 
                            <div class="text-danger">
                                <?= $error ?>
                                <?php break; ?>
                            </div>
                        <?php endforeach ?>
                        <?php unset($_SESSION['errors']['imagechemin']); ?>
                    <?php endif ?>
                </div>
            </div>

            <div class="form-group my-3">
                <label for="prix">Prix en € :</label>
                <input type="text" id="prix" name="prix" class="form-control" value="<?= $params['article']->prix ?>" required />
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['prix']) && !empty($_SESSION['errors']['prix']) ) : ?>
                    <?php foreach($_SESSION['errors']['prix'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['prix']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3">
            <label for="idmarque">Marque</label>
                <select name="idmarque" id="idmarque" class="form-control">       
                    <?php foreach ($params['marques'] as $marque) : ?>
                            <option value="<?=  $marque->id ?>"  <?=$marque->id == $params['article']->idmarque ? 'selected' : ' ' ?>> <?= $marque->nommarque ?> </option>
                    <?php endforeach ?>
                </select>
            
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['idmarque']) && !empty($_SESSION['errors']['idmarque']) ) : ?>
                    <?php foreach($_SESSION['errors']['idmarque'] as $error) : ?> 
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idmarque']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
            <label for="idutilisateur">Utilisateur Interne</label>
                <select name="idutilisateur" id="idutilisateur" class="form-control">   
                    <?php foreach ($params['utilisateurs'] as $utilisateur) : ?>
                            <option value="<?=  $utilisateur->id ?>"  <?= $utilisateur->id == $params['article']->idutilisateur ? 'selected' : ' ' ?>> <?php if($utilisateur->type === "utilisateur") : ?> <?= $utilisateur->prenom?>
                                <?php else : ?>
                                        <?= "" ?></option>
                                <?php endif ?>         </option>
                    <?php endforeach ?>
                </select>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['idutilisateur']) && !empty($_SESSION['errors']['idutilisateur']) ) : ?>
                    <?php foreach($_SESSION['errors']['idutilisateur'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idutilisateur']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
            <label for="idtaille">Taille flacon</label>
                <select name="idtaille" id="idtaille" class="form-control">       
                    <?php foreach ($params['tailles'] as $taille) : ?>
                            <option value="<?=  $taille->id ?>"  <?= $taille->id == $params['article']->idtaille ? 'selected' : ' ' ?>> <?= $taille->volumeflacon ?> </option>
                    <?php endforeach ?>
                </select>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['idtaille']) && !empty($_SESSION['errors']['idtaille']) ) : ?>
                    <?php foreach($_SESSION['errors']['idtaille'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idtaille']); ?>
                <?php endif ?>
            </div>
            <div class="form-group my-3">
            <label for="idgenre">Genre</label>
                <select name="idgenre" id="idgenre" class="form-control">       
                    <?php foreach ($params['genres'] as $genre) : ?>
                            <option value="<?=  $genre->id ?>"  <?= $genre->id == $params['article']->idgenre ? 'selected' : ' ' ?>> <?= $genre->libellegenre ?> </option>
                    <?php endforeach ?>
                </select>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['idgenre']) && !empty($_SESSION['errors']['idgenre']) ) : ?>
                    <?php foreach($_SESSION['errors']['idgenre'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['idgenre']); ?>
                <?php endif ?>
            </div>

            <div class="form-group my-3 text-center">
                <input type="submit" value="Modifier" class="btn btn-secondary" />
            </div>

        </form>
    </div>    
</div>
