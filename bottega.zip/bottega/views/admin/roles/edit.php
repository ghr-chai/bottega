<h1 class="d-flex justify-content-center text-primary my-3">Modifier rôle</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
        <form action="<?= URL ?>admin/roles/edit/<?= $params['role']->id ?>" class="w-50" method="POST"> 

            <div class="form-group my-3">
                <label for="libellerole">Rôle:</label>
                <input type="text" id="libellerole" name="libellerole" class="form-control" value="<?= $params['role']->libellerole ?>" required/>
                <!-- Affichage d'erreur  -->
                <?php if(isset($_SESSION['errors']['libellerole']) && !empty($_SESSION['errors']['libellerole']) ) : ?>
                    <?php foreach($_SESSION['errors']['libellerole'] as $error) : ?> 
                        <div class="text-danger">
                            <?= $error ?>
                            <?php break; ?>
                        </div>
                    <?php endforeach ?>
                    <?php unset($_SESSION['errors']['libellerole']); ?>
                <?php endif ?>
            </div>
            
            <div class="form-group my-3 text-center">
                <input type="submit" value="Modifier" class="btn btn-secondary" />
            </div>

        </form>
    </div>
</div>
