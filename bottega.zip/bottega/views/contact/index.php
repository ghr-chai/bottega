<h1 class="d-flex justify-content-center text-primary my-5">Page de Contact</h1>

<div class="container">
    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">   

        <form action="<?= URL ?>contact/merci" class="w-50" method="POST"> 
    
            <div class="form-group my-3">
                <label for="nom">Nom :</label>
                <input type="text" name="nom" id="nom" class="form-control" value="<?= $_POST['nom'] ?? '' ?>" required>  
            <!-- message d'erreur-->   
            </div>
            <div class="form-group my-3">
                <label for="prenom">Prénom :</label>
                <input type="text" name="prenom" id="prenom" class="form-control" value="<?= $_POST['prenom'] ?? '' ?>" required>  
            
            </div>
            <div class="form-group my-3">
                <label for="email">Email :</label>
                <input type="email" name="email" id="email" class="form-control" value="<?= $_POST['email'] ?? '' ?>" required>
            
            </div>
            <div class="form-group my-3">
                <label for="message">Votre Message :</label>
                <textarea name="message" id="message" class="form-control" rows="6"></textarea>
            </div>

            <div class="form-group my-3">
                <input type="checkbox" name="C1" id="case1" checked />
                <label for="case1">Je souhaite recevoir par mail les publicités ainsi que toutes les nouveautés.</label><br />
            </div>
            
            <div class="form-group my-3 text-center">
                <input type="submit"  class="btn btn-secondary" value="Envoyer" /> 
            </div>
            
        </form>
    </div>
</div>