<div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
    <?php      
        echo "Merci <strong> : ". ' '. $_POST['nom']. ' '. $_POST['prenom']. ' '. " , </strong>  on a bien reçu votre message! Vous trouverez une réponse sur votre boîte mail dans les plus brefs délais.  ";
    ?>   
</div>
