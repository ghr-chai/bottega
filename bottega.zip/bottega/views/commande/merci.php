<div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
    <?php      
        echo "<strong> ". ' '. $_SESSION['nom']. ' '. $_SESSION['prenom']. ' :'. "  </strong>  Votre paiement a passé avec succès. Vous allez recevoir votre livraison dans les plus brefs délais.  ";
    ?>   
</div>
