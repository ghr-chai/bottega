<h1 class="d-flex justify-content-center text-primary my-5">Page de Paiement</h1>


<div class="container">

    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">  

        <form action="<?= URL ?>paiement/merci/<?= $params['commande']->id ?>" class="w-50" method="POST"> 
    
            <div class="form-group my-3">
                <label for="adresselivraison">Adresse de la livraison :</label>
                <input type="text" name="adresselivraison" id="adresselivraison" class="form-control" value="<?= $_POST['adresselivraison'] ?? '' ?>" required>  
           
            </div>
            <div class="form-group my-3">
                <label for="adressefacturation">Adresse de la facturation :</label>
                <input type="text" name="adressefacturation" id="adressefacturation" class="form-control" value="<?= $_POST['adressefacturation'] ?? '' ?>" required>  
           
            </div>
            <fieldset>
                <!-- <legend class="d-flex justify-content-center my-3 ">Moyen de Paiement par Carte Bancaire</legend>
                    <div class="form-group my-3">
                        <label for="nomsurcarte">Nom sur la carte  :</label>
                        <input type="text" name="nomsurcarte" id="nomsurcarte" class="form-control" value="<?= $_POST['nomsurcarte'] ?? '' ?>" required>  
           
                    </div>
                    <div class="form-group my-3">
                        <label for="numerocarte">Numéro de la carte :</label>
                        <input type="text" name="numerocarte" id="numerocarte" class="form-control" minlength="16" maxlength="16" value="<?= $_POST['numerocarte'] ?? '' ?>"  required>  
           
                    </div>
                    <div class="form-group my-3">
                        <label for="datevaliditecarte">Date de validité :</label>
                        <input type="date" name="datevaliditecarte" id="datevaliditecarte" class="form-control" value="<?= $_POST['datevaliditecarte'] ?? '' ?>" required>  
           
                    </div> -->
                    <div class="form-group my-3">
                       
                        <label for="montantcommande">Montant de la commande en € :</label>
                        <input type="text" name="montantcommande" id="montantcommande" class="form-control" value="<?= $params['montantGlobal'] ?? '' ?>" disabled required>  
           
                    </div>
            </fieldset>
            <div class="form-group my-3 text-center">
                <input type="submit"  class="btn btn-secondary" value="Envoyer" /> 
            </div>
            
        </form>
    </div>
</div>