<h1 class="d-flex justify-content-center text-primary my-5">Page d'Inscription</h1>


<div class="container">

    <div class="alert alert-primary d-flex justify-content-center my-5" role="alert">  

        <form action="<?= URL ?>inscription/client" class="w-50" method="POST"> 
    
            <div class="form-group my-3">
                <label for="nom">Nom :</label>
                <input type="text" name="nom" id="nom" class="form-control" value="<?= $_POST['nom'] ?? '' ?>" required>  
            <!-- message d'erreur-->   
            </div>
            <div class="form-group my-3">
                <label for="prenom">Prénom :</label>
                <input type="text" name="prenom" id="prenom" class="form-control" value="<?= $_POST['prenom'] ?? '' ?>" required>  
            
            </div>
            <div class="form-group my-3">
                <label for="adresse">Adresse :</label>
                <input type="text" name="adresse" id="adresse" class="form-control" value="<?= $_POST['adresse'] ?? '' ?>" required>  
                
            </div>
            <div class="form-group my-3">
                <label for="tel">Tél :</label>
                <input type="tel" name="tel" id="tel" class="form-control" value="<?= $_POST['tel'] ?? '' ?>" required>  
            
            </div>
            <div class="form-group my-3">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" class="form-control" value="<?= $_POST['email'] ?? '' ?>" required>
            
            </div>
            <div class="form-group my-3">
                <label for="motdepasse">Mot de passe</label>
                <input type="password" name="motdepasse" id="motdepasse" class="form-control" value="<?= $_POST['motdepasse'] ?? '' ?>" required>
            
            </div>


            <div class="form-group my-3">
                
                <input type="hidden" name="type"  class="form-control" value="client">
            
            </div>
            <div class="form-group my-3">
                
                <input type="hidden" name="idutilisateur"  class="form-control" value="1">
            
            </div>
            <div class="form-group my-3">
                
                <input type="hidden" name="idrole"  class="form-control" value="3">
            
            </div>

            <div class="form-group my-3 text-center">
                <input type="submit"  class="btn btn-secondary" value="S'enregistrer" /> 
            </div>
            
        </form>
    </div>
</div>