<h1 class="d-flex justify-content-center text-primary my-5">Article Ajouté dans votre panier</h1>

<!-- table -->


     <?php if(isset($params['lignesCommande']) && !empty($params['lignesCommande'])) : ?>
        <div class="table-responsive">
            <table class="text-center table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                    
                        <th>Nom article</th>
                        <th>Quantité</th>
                        <th>Prix en € </th>
                        <th>Sous-Total</th>

                        <th>Paramètres</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($params['lignesCommande'] as $ligneCommande) : ?>
                    
                        <tr>
                            <td><?php $data = $ligneCommande->getNomArticle($ligneCommande->id); echo $data->nomarticle; ?></td>
                            <td><?= $data = $ligneCommande->qtecommandee ?></td>
                            <td><?= $data = $ligneCommande->prixunitvente ?></td>
                            <td><?= $data = $ligneCommande->qtecommandee * $ligneCommande->prixunitvente ?></td>
                            <td>
                                <a href="<?= URL ?>panier/<?= $_SESSION['idUtilisateur'] ?>" class="btn btn-secondary">Voir le panier</a>
                                <form action="#" method="POST" class="d-inline">
                                    <button type="submit" class="btn btn-danger">Vider</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>

    <?php else : ?>
        <h2 class="text-center my-5">
            Aucun article ajouté au panier pour le moment
        </h2>
    <?php endif ?>








    
