<h1 class="d-flex justify-content-center text-primary my-5"> <?= "Plus de Détails sur l'article : <u>" . $params['article']->nomarticle ?> </u></h1>

<!-- table -->


    <div class="table-responsive">
        <table class="text-center table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Marque</th>
                    <th>Genre</th>
                    <th>Taille</th>
                    <th>Prix</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                    <tr>
                        <td><img src="<?=$params['article']->imagechemin?>" width="100" height="100" alt="parfum"></td>
                        <td><?php $data = $params['article']->getNomMarque($params['article']->id); echo $data->nommarque; ?></td>
                        <td><?php $data = $params['article']->getGenre($params['article']->id); echo $data->libellegenre; ?></td>
                        <td><?php $data = $params['article']->getVolumeFlacon($params['article']->id); echo $data->volumeflacon; ?></td>
                        <td><?= $params['article']->prix ?>€</td>
                        <td><p><?= $params['article']->description ?></p></td>
                    </tr>             
            </tbody>
        </table>
    </div>
    <div class="d-flex justify-content-end align-items-center my-3">
        <a href="<?= URL ?>boutique" class="btn btn-secondary" >Retourner en arrière</a>
    </div>