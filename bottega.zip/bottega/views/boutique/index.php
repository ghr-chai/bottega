<?php if(isset($_SESSION['prenom'] ) && !empty($_SESSION['prenom']) && isset($_SESSION['nom'] ) && !empty($_SESSION['nom'] )) : ?> 
    
    <h1 class="d-flex justify-content-center text-primary my-3">Bonjour <?=$_SESSION['prenom'] ." ". $_SESSION['nom']. " !"?></h1> 
<?php else : ?>    
    
    <h1 class="d-flex justify-content-center text-primary my-5">Bienvenue dans ma Boutique!</h1>

    <div class="alert alert-warning alert-dismissible text-center text-ocean fade show" role="alert">
        Pour acheter vos parfums préférés : <strong>Inscrivez-vous dès maintenant!</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif ?>  

<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
<div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
      <?= $_SESSION['success'] ?> 
</div>
 
 
  <?php unset($_SESSION['success']); ?>
 <?php endif ?>  

    <!-- Pagination -->
    <ul class="pagination">
            <li class="page-item mx-1"><a class="page-link" href="<?= URL ?>boutique?page=1">Premier</a></li>
            <?php if($params['previousPageNbr']==1 && $params['currentPageNbr']==1) :?>
                <li class="page-item mx-1"><a class="page-link" href="<?= URL ?>boutique?page=<?=$params['previousPageNbr'] ?>" onclick="return false">Précédent</a></li>
            <?php else : ?>
                <li class="page-item mx-1"><a class="page-link" href="<?= URL ?>boutique?page=<?= $params['previousPageNbr'] ?>">Précédent</a></li>
            <?php endif ?>
            
            <li class="page-item active mx-1"><a class="page-link" href="#"><?= $params['currentPageNbr']  ?></a></li>
            <?php if($params['lastPageNbr']==$params['currentPageNbr']) :?>
                <li class="page-item mx-1"><a class="page-link" href="<?= URL ?>boutique?page=<?= $params['nextPageNbr'] ?>" onclick="return false">Suivant</a></li>
            <?php else : ?>
                <li class="page-item mx-1"><a class="page-link" href="<?= URL ?>boutique?page=<?= $params['nextPageNbr'] ?>">Suivant</a></li>
            <?php endif ?>    
                <li class="page-item mx-1"><a class="page-link" href="<?= URL ?>boutique?page=<?= $params['lastPageNbr'] ?>">Dernier</a></li>
            
    </ul>
      
<!-- Système de grid -->
  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3"> 
        <?php if(isset($params['articleList']) && !empty($params['articleList'])) : ?>
            <?php foreach($params['articleList'] as $article) : ?>
                <div class="col">
                    <div class="card shadow-sm">
                        <div class="d-flex justify-content-start align-items-center mx-2 my-2">
                            <h5 class="text-ocean"><?= $article->nomarticle?></h5>
                        </div>
                        <div class="d-flex justify-content-center align-items-center my-3">
                            <img src="<?=$article->imagechemin ?>"width="150" height="150" alt="parfum">
                        </div>
                        <div class="card-body">
                            <p class="card-text"><?=substr($article->description, 0, 60);?>.</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                            
                                    <a href="<?= URL ?>boutique/<?= $article->id ?>" class="btn btn-sm btn-outline-secondary">Voir Plus</a>
                                    <?php if(isset($_SESSION['typeUtilisateur']) && $_SESSION['typeUtilisateur'] === "client") : ?>    
                                        <a href="<?= URL ?>boutique/compte/<?= $article->id ?>" class="btn btn-sm btn-outline-secondary">Acheter</a>
                                    <?php else : ?>
                                        <input type="button" value="Acheter" class="btn btn-sm btn-outline-secondary" disabled>
                                    <?php endif ?>

                                </div>
                            <small class="text-muted"><?=$article->prix ?> €</small>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
    <?php else : ?>
          <?= "<h3 class='text-ocean'>Aucun Résultat trouvé.</h3>" ?>

    <?php endif ?>

</div>