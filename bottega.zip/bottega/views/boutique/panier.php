<h1 class="d-flex justify-content-center text-primary my-5"> Contenu de votre Panier: <?=$_SESSION['prenom'] ." ". $_SESSION['nom']?></h1>

<!-- table -->

    

<?php if(isset($params['lignesCommande']) && !empty($params['lignesCommande'])) : ?>
        <div class="table-responsive">
            <table class="text-center table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                    
                        <th>Nom article</th>
                        <th>Quantité</th>
                        <th>Prix en € </th>
                        <th>Sous-Total</th>

                        <th>Paramètres</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($params['lignesCommande'] as $ligneCommande) : ?>
                        <!-- <?php print_r($ligneCommande);?> -->
                        <tr>
                            <td><?= $data = $ligneCommande->nomarticle ?></td>
                            <td><input type="number" name="qtecommandee" value="<?= $data = $ligneCommande->qtecommandee ?>"/></td>
                            <td><?= $data = $ligneCommande->prixunitvente ?></td>
                            <td><?= $data = $ligneCommande->qtecommandee * $ligneCommande->prixunitvente ?></td>
                           
                        

                            <td>
                                <a href="<?= URL ?>modifierQuantiteDuPanier/<?= $ligneCommande->id ?>" class="btn btn-secondary">Modifier</a>
                                <form action="<?= URL ?>supprimerDuPanier/<?=$ligneCommande->id ?>" method="POST" class="d-inline">
                                    <button type="submit" class="btn btn-danger">Annuler</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
        <?php if(isset($params['montantGlobal']) && !empty($params['montantGlobal'])) : ?>
            <div class="d-flex justify-content-center align-items-center my-3"><?="Le montant Global de votre commande en préparation est égale à <strong> ".' '. $params["montantGlobal"].' €</strong> .' ?></div>
        <?php endif ?>
        <div class="d-flex justify-content-center align-items-center my-3">
            <a href="<?= URL ?>paiement/<?= $_SESSION['idUtilisateur'] ?>" class="btn btn-secondary">Passer la commande</a>
        </div>
<?php else : ?>
    <h2 class="text-center my-5">
        Aucune ligne de Commande ajoutée au panier pour le moment
    </h2>
<?php endif ?>