<h1 class="d-flex justify-content-center text-primary my-5"> <?= "Acheter l'article : <u>" . $params['article']->nomarticle ?> </u></h1>

<!-- table -->
<?php if(isset($_SESSION['success']) && !empty($_SESSION['success'])) :?>
 
<div class="alert alert-primary d-flex justify-content-center my-5" role="alert">
     <?= $_SESSION['success'] ?> 
 </div>


 <?php unset($_SESSION['success']); ?>
<?php endif ?>

   
    <form action="<?= URL ?>ajouterAuPanier/<?= $params['article']->id ?>" method=POST  class="d-inline">

        <div class="table-responsive">
            <table class="text-center table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Marque</th>
                        <th>Genre</th>
                        <th>Taille</th>
                        <th>Prix</th>
                        <th>Quantité à commander</th>
                    
                    </tr>
                </thead>
                <tbody>
                        <tr>
                            <td><img src="<?=$params['article']->imagechemin?>" width="100" height="100" alt="parfum"></td>
                            <td><?php $data = $params['article']->getNomMarque($params['article']->id); echo $data->nommarque; ?></td>
                            <td><?php $data = $params['article']->getGenre($params['article']->id); echo $data->libellegenre; ?></td>
                            <td><?php $data = $params['article']->getVolumeFlacon($params['article']->id); echo $data->volumeflacon; ?></td>
                            <td><?= $params['article']->prix ?>€</td>

                            
                            <td><input
                                type="number"
                                name="qtecommandee" 
                                min="1"
                                value="1" required/></td>
                        
                        </tr>             
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-end align-items-center my-3">
            <button type="submit" class="btn btn-primary">Ajouter au panier</button>
        </div>
        
    </form>

    
    <div class="d-flex justify-content-end align-items-center my-3">
        <a href="<?= URL ?>compte" class="btn btn-secondary" >Retourner en arrière</a>

    </div>
