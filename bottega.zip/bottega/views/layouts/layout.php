<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- Référencement Naturel -->
    <title>Boutique - parfums - parfumer - commande en ligne</title>
   
    <!-- styles: les links du CSS sont mis dans <head> car css est utilisé pour mettre en forme le contenu HTML.
 -->
    <link rel="stylesheet" href="<?= SCRIPTS . 'css' . DIRECTORY_SEPARATOR . 'app.css' ?>">
    <link rel="stylesheet" href="<?= SCRIPTS . 'css' . DIRECTORY_SEPARATOR . 'style.css' ?>">
    
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand mx-1" href="<?= URL ?>accueil">Parfums de rêve</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" 
        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" 
        aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">

                <li class="nav-item">
                    <a class="nav-link" href="<?= URL ?>accueil">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick='alerter()' href="<?= URL ?>boutique">Boutique</a>
                </li>
                <?php if(isset($_SESSION['auth']) && !empty ($_SESSION['auth'])) : ?>
                    <?= "" ?>
                <?php else : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= URL ?>inscription">S'inscrire</a>
                    </li>
                <?php endif ?>        
                <?php if(isset($_SESSION['auth']) && $_SESSION['auth'] === 1) : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= URL ?>espaceReserve">Espace Admin</a>
                    </li>
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                                <a class="nav-link" href="<?= URL ?>deconnexion">Déconnexion</a>
                        </li>
                    </ul>
                <?php elseif(isset($_SESSION['auth']) && $_SESSION['auth'] === 3) : ?>

                    <li class="nav-item">
                    <a class="nav-link" href="<?= URL ?>contact">Contact</a>
                </li>
                   
                    <li class="nav-item">
                        <a class="nav-link" href="<?= URL ?>panier/<?= $_SESSION['idUtilisateur'] ?>">Panier <span class="badge bg-danger">
                            <?php if(isset($_SESSION['nbreArticles']) && !empty($_SESSION['nbreArticles'])) : ?>
                                    <?=$_SESSION['nbreArticles']?>
                            <?php else : ?>
                                    <?= 0 ?>
                            <?php endif ?>        
                        </span></a>
                    
                    </li>
                    <ul class="navbar-nav me-auto ">
                        <li class="nav-item">
                                <a class="nav-link" href="<?= URL ?>deconnexion">Déconnexion</a>
                        </li>
                    </ul>
                <?php else : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= URL ?>connexion">Connexion</a>
                    </li>
                <?php endif ?>
                <form class="d-flex me-2" action="<?= URL ?>boutique/Article/Recherche"  method="GET">
                    <input class="form-control me-2" placeholder="Rechercher parfum..." 
                    name="rechercheparfum" 
                    <?php if(isset($_GET['rechercheparfum']) && !empty($_GET['rechercheparfum'])) : ?>
                        value="<?= $_GET['rechercheparfum'] ?>" 
                    <?php else : ?>
                        value="<?= '' ?>"
                    <?php endif ?>         
                    style="border-radius: 30px;">
                    <input class="btn btn-outline-primary" type="submit" value="Rechercher" style="border-radius: 30px;"/>
                </form>
            </ul>

        </div>
    </nav>
    <!-- dans notre fonction view $content sera le require de nos différents vues et qu'on l'appellerai du coup à l'intérieur dans un dernier require qui sera du layout.php -->
    <main class="container-fluid">
            <?= $content ?>
    </main> 

    <footer class="navbar navbar-expand-lg navbar-dark bg-dark my-5">
        <div class="container"> 
            <div class="d-flex justify-content-center" >
                <p class="text-center text-white">Boutique Parfums de rêve 2021.</p>
            </div>
              
            <ul class="navbar-nav ms-auto">    
                <li class="nav-item">
                    <a class="text-white" href="<?= URL ?>boutique">Retour au site</a>
                </li>
            </ul>
        </div>
    </footer>

    <!-- un navigateur va lire et exécuter le code dans l’ordre de son écriture.Lorsque il arrive à un élément script, il va stopper le traitement du reste du HTML jusqu’à ce que le code Js soit chargé dans la page et exécuté.c'est pourquoi c'est préférable de mettre le Js à la fin du body pour s'assurer que la totalité de la page HTML est chargé         -->
    <script src="<?= SCRIPTS . 'javascript' . DIRECTORY_SEPARATOR . 'app.js' ?>"></script>
    
</body>
</html>