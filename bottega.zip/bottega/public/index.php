<?php
session_start();
//cela crée 1 fichier de session (sur le serveur) 
use Router\Router;
    // dès qu'on crée une nouvelle instance de mes classes, on n'a pas besoin de require de fichiers, juste on écrit:
    require "../vendor/autoload.php";

    //on va définir la constante VIEWS qui sera un chemin qui va nous pointer vers notre dossier views ; la constante prédéfinie DIR nous permet d'appeler notre dossier public et la fonction dirname permet de faire un pas en arrière (renvoie le chemin du dossier parent) par rapport à public et dans notre cas ça sera notre dossier app concaténé par la constante DIRECTORY_SEPARATOR qui est un slash"/" concaténé par notre dossier views concaténé par un slash à la fin.
    define ('VIEWS', dirname(__DIR__). DIRECTORY_SEPARATOR. 'views' . DIRECTORY_SEPARATOR);
    define ('SCRIPTS', dirname($_SERVER['SCRIPT_NAME']). DIRECTORY_SEPARATOR);

    // la constante URL nous ramène à notre page router ($_SERVER[PHP_SELF]qui renvoie le nom de fichier du script en cours d'exécution .)
    define("URL", str_replace('public/index.php', '', (isset($_SERVER['HTTPS']) ? 'https' : 'http') . "://$_SERVER[HTTP_HOST]$_SERVER[PHP_SELF]"));
    define("DB_NAME", 'bottega');
    define("DB_HOST", '127.0.0.1');
    define("DB_USER", 'root');
    define("DB_PWD", '');
    //echo $_GET['page'];
    // on crée une instance de la classe Router qui prend en paramètre l'url nommé variable url 
    //et on le récupère grâce à notre variable globale $_Get comme définit dans notre fichier .htaccess
    $router = new Router($_GET['url']);
    //$router->show();
    // on crée une route inspirée du framework Laravel(MVC) ;on appelle la méthode get qui prend en paramètres 2:
    // le path et l'action qui est composée de controller, @ et méthode ;le path est '/' appelle un controlleur qui est AccueilController qui va appeler la méthode index.r
    $router->get ('/', 'App\Controllers\AccueilController@index');
    //on crée une route en get aussi qui prend en paramètres 2:
    // le path et l'action ;le path est '/articles/:id' appelle le même controlleur qui va appeler la méthode show qui va attendre en argument l'id de articles
    // $router->get ('/articles/:id', 'App\Controllers\ArticleController@show');
    // on crée une méthode run pour vérifier sur nos différentes routes s'il ya quelque chose qui matche
    
    

    // ROUTE articles
    $router->get ('accueil', 'App\Controllers\AccueilController@index');
    $router->get ('/boutique', 'App\Controllers\ArticleController@index');
    $router->get ('/boutique/:id', 'App\Controllers\ArticleController@show');
    $router->get ('/compte', 'App\Controllers\ArticleController@indexCompte');
    $router->get ('/boutique/compte/:id', 'App\Controllers\ArticleController@showCompte');
    $router->get ('/boutique/Article/Recherche', 'App\Controllers\ArticleController@rechercher');

    // Route inscription
    $router->get ('/inscription', 'App\Controllers\InscriptController@create');
    $router->post ('/inscription/client', 'App\Controllers\InscriptController@createClient');

    // Route connexion
    $router->get ('/connexion', 'App\Controllers\UtilisateurController@login');
    $router->post ('/monCompte', 'App\Controllers\UtilisateurController@loginPost');
    $router->get ('/espaceReserve', 'App\Controllers\UtilisateurController@index');
    $router->get ('/deconnexion', 'App\Controllers\UtilisateurController@logout');

    // Route contact
    $router->get ('/contact', 'App\Controllers\ContactController@index');
    $router->post ('/contact/merci', 'App\Controllers\ContactController@indexMerci');

    // Route panier
    $router->get('/panier/:idutilisateur', 'App\Controllers\LigneCommandeController@contenuPanier');
    $router->post ('/ajouterAuPanier/:id', 'App\Controllers\LigneCommandeController@ajouterAuPanier');
    $router->post ('/supprimerDuPanier/:id', 'App\Controllers\LigneCommandeController@delete');
    $router->get ('/modifierQuantiteDuPanier/:id', 'App\Controllers\LigneCommandeController@modifier');

    //Route paiement
    $router->get('/paiement/:idutilisateur', 'App\Controllers\CommandeController@payer');
    $router->post ('/paiement/merci/:idcommande', 'App\Controllers\CommandeController@indexMerci');
    
    // ROUTES ADMINISTRATION

    //1----marques
    $router->get ('/admin/marques', 'App\Controllers\Admin\AdminMarqueController@index');
    $router->get ('/admin/marques/create', 'App\Controllers\Admin\AdminMarqueController@create');
    $router->post ('/admin/marques/create', 'App\Controllers\Admin\AdminMarqueController@createMarque');
    $router->post('/admin/marques/delete/:id', 'App\Controllers\Admin\AdminMarqueController@destroy');
    $router->get('/admin/marques/edit/:id', 'App\Controllers\Admin\AdminMarqueController@edit');
    $router->post('/admin/marques/edit/:id', 'App\Controllers\Admin\AdminMarqueController@update');
   
    //2----genres
    $router->get ('/admin/genres', 'App\Controllers\Admin\AdminGenreController@index');
    $router->get ('/admin/genres/create', 'App\Controllers\Admin\AdminGenreController@create');
    $router->post ('/admin/genres/create', 'App\Controllers\Admin\AdminGenreController@createGenre');
    $router->post('/admin/genres/delete/:id', 'App\Controllers\Admin\AdminGenreController@destroy');
    $router->get('/admin/genres/edit/:id', 'App\Controllers\Admin\AdminGenreController@edit');
    $router->post('/admin/genres/edit/:id', 'App\Controllers\Admin\AdminGenreController@update');

    //3----tailles
    $router->get ('/admin/tailles', 'App\Controllers\Admin\AdminTailleController@index');
    $router->get ('/admin/tailles/create', 'App\Controllers\Admin\AdminTailleController@create');
    $router->post ('/admin/tailles/create', 'App\Controllers\Admin\AdminTailleController@createTaille');
    $router->post('/admin/tailles/delete/:id', 'App\Controllers\Admin\AdminTailleController@destroy');
    $router->get('/admin/tailles/edit/:id', 'App\Controllers\Admin\AdminTailleController@edit');
    $router->post('/admin/tailles/edit/:id', 'App\Controllers\Admin\AdminTailleController@update');

    //4----utilisateurs
    $router->get ('/admin/utilisateurs', 'App\Controllers\Admin\AdminUtilisateurController@index');
    $router->get ('/admin/utilisateurs/create', 'App\Controllers\Admin\AdminUtilisateurController@create');
    $router->post ('/admin/utilisateurs/create', 'App\Controllers\Admin\AdminUtilisateurController@createUtilisateur');
    $router->post('/admin/utilisateurs/delete/:id', 'App\Controllers\Admin\AdminUtilisateurController@destroy');
    $router->get('/admin/utilisateurs/edit/:id', 'App\Controllers\Admin\AdminUtilisateurController@edit');
    $router->post('/admin/utilisateurs/edit/:id', 'App\Controllers\Admin\AdminUtilisateurController@update');

    //5----articles
    $router->get ('/admin/articles', 'App\Controllers\Admin\AdminArticleController@index');
    $router->get ('/admin/articles/create', 'App\Controllers\Admin\AdminArticleController@create');
    $router->post ('/admin/articles/create', 'App\Controllers\Admin\AdminArticleController@createArticle');
    $router->post('/admin/articles/delete/:id', 'App\Controllers\Admin\AdminArticleController@destroy');
    $router->get('/admin/articles/edit/:id', 'App\Controllers\Admin\AdminArticleController@edit');
    $router->post('/admin/articles/edit/:id', 'App\Controllers\Admin\AdminArticleController@update');

    //6----stocks
    $router->get ('/admin/stocks', 'App\Controllers\Admin\AdminStockController@index');
    $router->get ('/admin/stocks/create', 'App\Controllers\Admin\AdminStockController@create');
    $router->post ('/admin/stocks/create', 'App\Controllers\Admin\AdminStockController@createStock');
    $router->post('/admin/stocks/delete/:id', 'App\Controllers\Admin\AdminStockController@destroy');
    $router->get('/admin/stocks/edit/:id', 'App\Controllers\Admin\AdminStockController@edit');
    $router->post('/admin/stocks/edit/:id', 'App\Controllers\Admin\AdminStockController@update');

    //7----commandes
    $router->get ('/admin/commandes', 'App\Controllers\Admin\AdminCommandeController@index');

    //8----lignecommande
    $router->get ('/admin/lignesCommandes', 'App\Controllers\Admin\AdminLigneCommandeController@index');
    
    //9----roles
    $router->get ('/admin/roles', 'App\Controllers\Admin\AdminRoleController@index');
    $router->get ('/admin/roles/create', 'App\Controllers\Admin\AdminRoleController@create');
    $router->post ('/admin/roles/create', 'App\Controllers\Admin\AdminRoleController@createRole');
    $router->post('/admin/roles/delete/:id', 'App\Controllers\Admin\AdminRoleController@destroy');
    $router->get('/admin/roles/edit/:id', 'App\Controllers\Admin\AdminRoleController@edit');
    $router->post('/admin/roles/edit/:id', 'App\Controllers\Admin\AdminRoleController@update');



    // cette méthode permet de vérifier sur nos différentes routes s'il ya quelque chose qui matche 
    try{
        $router->run(); 
    } catch (\Exception $e){
        //si l'url n'existe pas dans la liste des routes, on rattrape l'erreur et on appelle un getter getMessage pour afficher le message de l'exception
        echo $e->getMessage();
    }