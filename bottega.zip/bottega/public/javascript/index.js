// Tu selectionne l'element HTML ayant l'id hello pour le placer dans une constante
const citation = document.getElementById("hello");
const texte = citation.dataset.label;
let i 	= 0 ;
function showLetters()
{
  let timeOut ;
  //on crée une boucle avec length calcule le nbre d'éléments (les lettres dans notre cas) dans la constante texte
  if(i < texte.length)
	{
      //avec innerHtml on change et on affiche le contenu de notre élément citation en concaténant lettre par lettre le contenu de datalabel
	  citation.innerHTML += `<span>${texte[i]}</span>` ;
      //La méthode setTimeout() appelle la fonction showLetters après 200 millisecondes.
	  timeOut = setTimeout(showLetters,200)
	  i++
	}
	else
	{
    // sinon on empêche l'exécution de la fonction par clearTimeout()
	  clearTimeout(timeOut);
	  console.log("end")
	}
}
showLetters();

