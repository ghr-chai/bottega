<?php
namespace Router;

use Database\Dbconnection;

    class Route{
        // 2 les 2 paramètres path et action une fois récupéré on les stocke dans 2 attributs
        public $path;
        public $action;

        public $matches;
        // 1 on crée une fonction constructrice qui récupère ces 2 paramètres
        public function __construct($path, $action){
            // dans le path on va stocker le path qu'on vient de l'envoyer
            $this->path = trim($path,'/');
            // dans l'action on va stocker l'action qu'on vient de l'envoyer
            $this->action = $action;
        }
        public function matches(string $url){
          
            // on utilise preg_replace , au niveau du pattern on cherche à remplacer tout ce qui commencerai avec ":" et qui serait après un caractère alphanumérique[\w] et ça va se répéter plusieurs fois "+", par une expression régulière "^/" c'est à dire ne soit pas un slash 
            $path = preg_replace ('#:([\w]+)#', '([^/]+)', $this->path);
            //on va passer tout le path en entier ^$ à notre preg_match pour effectuer une recherche
            // de correspondance avec une expression régulière
            $pathToMatch = "#^$path$#";
           //on veut tester $pathToMatch dans l'url c'est pourquoi le sujet est $url et $matches c'est un tableau qui va contenir le paramètre voulu,dans la première clé sera $url et la deuxième sera l'id de notre article par exemple
            if(preg_match($pathToMatch, $url, $matches)){
                // print_r($matches);
                $this->matches = $matches;
                return true;
            }
            else{
                return false;
            }

        }
        //grâce à cette fonction qu'on va récupérer le bon controlleur avec la bonne méthode
        public function execute(){
            // on  crée la variable $params dont la fonction explode retourne un tableau de chaînes de caractères
            // on va exploser l'action par @(c'est notre délimiteur) pour avoir un tableau params dont son indice 0
            // c'est le controlleur et son indice 1 c'est la méthode
            $params = explode('@', $this->action);
            // on va créer une nouvelle instance de notre controlleur en lui passant l'instantiation de la connexion comme définit dans la fonction constructrice de la classe mère Controller
            // $controller = new $params[0](new Dbconnection('bottega', '127.0.0.1', 'root', ''));
            $controller = new $params[0](new Dbconnection(DB_NAME, DB_HOST, DB_USER, DB_PWD));
            // $controller = new $params[0]();
            //on va récupérer notre méthode qui est l'indice 1 du tableau params
            $method = $params[1];
            // on ajoute un condition car c'est pas toujours le cas qu'on a quelque chose dans $matches
            //on définit une expression ternaire: et on vérifie si $matches[1] existe c'est elle qui
            // va contenir l'id(/:id)
            //si vrai, on appelle le bon controller avec la bonne méthode et on la passe la valeur de matches[1] qui
            // est l'id
            //si non , on apelle le bon controller avec une simple méthode qui 
            //est une page d'acceuil par exemple ou page statique
            return isset($this->matches[1]) ? $controller->$method($this->matches[1]) : $controller->$method();

        }

    
}   