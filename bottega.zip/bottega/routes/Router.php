<?php
namespace Router;// définit dans composer.json


// on crée une classe Router:
    class Router
    {
        // $url contiendra l'url sur laquelle on souhaite se rendre
        // 2 l'url récupéré dans la fonction constructrice, je le stocke dans un attribut:
        private $url;
        // $routes contiendra la liste des routes
        // 4 on va enregistrer nos routes dans la variable $routes qui sera un tableau vide:
        private $routes = [];
        // 1 on crée une fonction constructrice qui récupère l'url en paramètre nommé $url:
        public function __construct($url){
            // on renvoie l'url récupéré directement en variable et on ajoute la fonction trim pour supprimer toute / au début et à la fin de l'url pour éviter tout souci
            $this->url = trim($url, '/');
        }
        
        //public function show(){
            //echo $this->url;}
        // 3 on va créer la méthode get qui attend un path et une action (MVC)
        public function get(string $path, string $action){
        //au lieu de lister mes routes dans un tableau $routes les unes après les autres ,on peut les trier comme suit
        //on renvoie routes qui aurait la clé Get et cette clé va nous donner l'accès à un tableau dans lequel je pusherai ma route
        //et ma route ça sera une nouvelle instance de la classe Route qu'on va créer et qui prend en paramètres path et action
           $route = new Route($path, $action);
           $this->routes['GET'][] = $route;
           // on retourne la route pour enchaîner les méthodes
           return $route;
        }
        public function post(string $path, string $action){
           
               $route = new Route($path, $action);
               $this->routes['POST'][] = $route;
               
               return $route;
            }

        // on va créer la méthode run qui va boucler sur nos routes et vérifier s'il ya une route qui matche avec l'url entrée
        public function run(){
        //dans foreach on va appeler les routes dans la clé ça sera ni GET ni POST en dur mais d'une façon dynamique, on va utiliser la superVariable SERVER
            foreach($this->routes[$_SERVER['REQUEST_METHOD']] as $route){
                // la route aura une méthode matches qui prend en paramètre l'url dans notre cas nommé url
                //en bouclant, si notre route matche avec notre url alors
                if ($route->matches($this->url)){
                    //on appelle notre route avec la fonction execute et cette fonction va appeler le bon controlleur avec la bonne méthode
                    return $route->execute();
                }  
            }
            //header envoie un en-tête HTTP
            // return  header('HTTP/1.0 404 NOT FOUND');
            
            // pour personnaliser le message d'erreur on utilise throw pour lancer une nouvelle exception qui est une classe native de PHP et qui se trouve à la racine on lui indique un bach slash, et au niveau de la construction de cette classe exception on s'attend à un message.
            throw new \Exception("La page demandée est introuvable.");
           
        }
    }

