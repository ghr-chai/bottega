<?php
namespace App\Controllers;// déjà définit dans composer.json


use App\Controllers\Controller;



    class ContactController extends Controller
    {
        
        public function index(){ 
           
            return $this->view("contact.index");
        }

        public function indexMerci(){ 
           
            return $this->view("contact.merci");
        }

    }