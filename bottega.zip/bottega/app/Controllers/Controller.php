<?php
namespace App\Controllers;

use Database\Dbconnection;
// on a passé la classe Controller en abstract car elle ne sera jamais instanciée
    abstract class Controller {

        // protected car la connexion est appelée que par les enfants du Controller générique
        protected $db;
        // à la construction du Controlleur , on va prendre une instance de Dbconnection et on va la stocker dans $db
        public function __construct(Dbconnection $db)
        {
            $this->db = $db;
        }
        // on a passé la fonction view en protégé car elle ne sera appelée que par les classes enfants de controller la fonction view prend en arguments en premier le chemin de la vue et en second qui sera optionnel et null par défaut, qui sera un tableau appelé $params puisque c'est ça se que fait la fonction compact et dans la clé sera les données qu'on veut les afficher dans la vue 
        protected function view(string $path, array $params = null){
            //On appelle la fonction ob_start() (ligne 3) qui "mémorise" toute la sortie HTML qui suit, puis, à la fin, on récupère le contenu généré avec ob_get_clean()  (ligne 28) et on met le tout dans $content .
            
            //ob_start est une fonction qui crée un tampon de sortie dans ce cas c'est la vue
            ob_start();
            // on va définir $path et on va chercher les "." et les remplacer par"/", et ça on va le faire dans $path
            $path = str_replace('.', DIRECTORY_SEPARATOR, $path);
            // on appelle un require du chemin de notre dossier views :notre constante VIEWS concaténé par $path sans ajouter "/" car déjà ajouté dans la définition de VIEWS dans index.php concaténé par "php"
            require VIEWS.$path.'.php';
            //ob_get_clean fonction renvoie le contenu du tampon de sortie, puis supprime le contenu du tampon, on va stocker notre vue dans $content
            $content = ob_get_clean();
            require VIEWS. 'layouts/layout.php';
            
        }

        public function redirect_back()
        {
            header("Location: " . $_SERVER['HTTP_REFERER']);
            die();
        }

        public function redirect_to_url($path)
        {
            header("Location: " . URL . $path);
            die();
        }
        // ona crée un getter pour récupérer la connection à la base de données et on l'a passé en protégé cer elle sera appelée que par les classes enfants de Controller
        protected function getDB(){

            return $this->db;
        }

        protected function isAdmin(){

            if(isset($_SESSION['auth']) && $_SESSION['auth'] === 1){
                //on va donner l'accès au back-end la partie administration
                return true;
                
            } else{

                return $this->view('auth.connexion');
            }
        }
}

        
    