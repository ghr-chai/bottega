<?php
namespace App\Controllers;// déjà définit dans composer.json


use App\Models\Article;
use App\Models\Commande;
use App\Models\Utilisateur;
use App\Models\LigneCommande;
use App\Validation\Validator;
use App\Controllers\Controller;



    class UtilisateurController extends Controller
    {
        // renvoyer la vue Page de connexion :
        public function login(){

            return $this->view('auth.connexion');

        }
        //cette fonction traitera de la logique à partir des données envoyées depuis le formulaire de connexion
        // récupérer l'utilisateur d'après son email :
        public function loginPost(){
            
            //on va récupérer un utilisateur et on va lui passer la connexion à la BD, on va englober tout ça et appeler une méthode chercherEmail pour chercher cet utilisateur à partir de son email puisque c'est unique
            $utilisateur = (new Utilisateur($this->getDB()))->chercherEmail($_POST['email']);
            if(!$utilisateur){

                $_SESSION['erreur']="Vos identifiants sont incorrects, Veuillez entrer des identifiants valides.";
                return $this->view("auth.connexion");
            }
            
            $utilisateur = (new Utilisateur($this->getDB()))->getByEmail($_POST['email']);
            //on vérifie si on récupère bien une instance d'Utilisateur
            // var_dump($utilisateur);

            if(isset($utilisateur->email)){

            // on vérifie si le mot de passe envoyé correspond bien à celui haché dans la BD
            if(password_verify($_POST['motdepasse'], $utilisateur->motdepasse)){
            // on vérifie si notre utilisateur est admin càd idrole=1 si oui, on lui donne l'accès au backend 
                // $_SESSION['prenom'] = (string) $utilisateur->prenom;
                $_SESSION['auth'] = (int) $utilisateur->idrole;
                $_SESSION['typeUtilisateur'] = $utilisateur->type;

                if(isset($_SESSION['auth']) && $_SESSION['auth'] === 1){

                    $_SESSION['success'] = "L'administrateur est connecté Maintenant !";
                    return $this->view("admin.index");

                }else if(isset($_SESSION['auth']) && $_SESSION['auth'] === 3){

                    $_SESSION['success'] = "Vous êtes connecté Maintenant !";
                    $_SESSION['nom'] = $utilisateur->nom;
                    $_SESSION['prenom'] = $utilisateur->prenom;
                    $_SESSION ['idUtilisateur']=$utilisateur->id;
                    $_SESSION['typeUtilisateur'] = $utilisateur->type;
                    $article = new Article($this->getDB());
                    $articles = $article->all();
                    $utilisateurs = (new Utilisateur($this->getDB()))->all();

                    
                    $commande = (new Commande($this->getDB()))->getByUtilisateurAndStatus($_SESSION['idUtilisateur'], 
                                                             Commande::EtatEnPreparation);
                    if(!$commande)
                    {
                        $_SESSION['nbreArticles']= 0; 

                    }else{
    
                        $lignesCommande = (new LigneCommande($this->getDB()))->
                                            getAllLigneCommandeByCommandeAndDetailsArticles($commande->id);

                        $totalArticles =(new LigneCommande($this->getDB()))->getNbreArticlesDeCommandeEnPreparation($commande->id);
                    
                        if($lignesCommande && $totalArticles ){  

                            $_SESSION['nbreArticles']= $totalArticles;
                        
        
                        }else{
        
                            $_SESSION['nbreArticles']= 0;
                        }
                    }
                   

                    return $this->redirect_to_url("boutique");
                }
                else{
                    return $this->view('auth.connexion');
                }
            }else{
            $_SESSION['erreur']="Votre mot de passe est incorrect, Veuillez entrer un mot de passe valide.";
            return $this->view("auth.connexion");
        }
    }
}

    public function index(){

        return $this->view("admin.index");
        
    }

    public function logout(){

        session_destroy();
        $article = new Article($this->getDB());
        $articles = $article->all();
        $utilisateurs = (new Utilisateur($this->getDB()))->all();
        return $this->redirect_to_url("boutique");
    }


}