<?php
namespace App\Controllers;// déjà définit dans composer.json

use App\Models\Commande;
use App\Models\LigneCommande;

    class CommandeController extends Controller
    {
        public function payer(){

            $commande = (new Commande($this->getDB()))->getByUtilisateurAndStatus($_SESSION['idUtilisateur'], 
                                                             Commande::EtatEnPreparation);
 
            $montantGlobal =(new LigneCommande($this->getDB()))->getMontantGlobalDeCommandeEnPreparation($commande->id);

            return $this->view("commande.paiement", compact('montantGlobal', 'commande'));
        }

        public function indexMerci($id){ 


            $commandeMiseAjour=(new Commande($this->getDB()))->mettreAjourStatusEtAdresseLivraison($_POST['adresselivraison'], 
            Commande::EtatEnCours, $id );

            $_SESSION['nbreArticles']= 0;
           
            return $this->view("commande.merci");
        }


    }