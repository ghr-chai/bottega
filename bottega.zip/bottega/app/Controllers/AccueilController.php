<?php
namespace App\Controllers;


use App\Controllers\Controller;



    class AccueilController extends Controller
    {
        
        public function index(){ 
           
            return $this->view("accueil");
        
        }

     

    }