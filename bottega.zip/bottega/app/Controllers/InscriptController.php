<?php
namespace App\Controllers;// déjà définit dans composer.json


use App\Models\Utilisateur;
use App\Validation\Validator;
use App\Controllers\Controller;



    class InscriptController extends Controller
    {
        
        public function create(){ 
           
            return $this->view("inscription.index");
        }

        public function createClient(){ 

            if ($_SERVER['REQUEST_METHOD'] === "POST") 
            {
                $validator = new Validator($_POST);
    
                $errors = $validator->validate([
    
                    "nom" => ["required", "min:2"],
                    "prenom" => ["required", "min:2"],
                    "adresse" =>["required"],
                    "tel" =>["required"],
                    "email" =>["required"],
                    "motdepasse" =>["required"],
                    "type" =>["required"]
                    
                ]);
                 if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
                    {
                        $errors['email'] = "Veuillez entrer un email valide.";
                    }
                if($errors){
                    $_SESSION['errors'] = $errors;
    
                        foreach ($_POST as $key => $value) 
                        {
                            $_SESSION['previous_input'][$key] = $value; 
                        }
    
                        // On redirige l'internaute vers la page de départ
                        return $this->redirect_back();
                }
    
                $nom_clean = htmlspecialchars(addslashes(trim($_POST['nom'])));
                $prenom_clean = htmlspecialchars(addslashes(trim($_POST['prenom'])));
                $adresse_clean = htmlspecialchars(addslashes(trim($_POST['adresse'])));
                $tel_clean = htmlspecialchars(addslashes(trim($_POST['tel'])));
                $email_clean = htmlspecialchars(addslashes(trim($_POST['email'])));
                $motdepasse_clean = htmlspecialchars(addslashes(trim($_POST['motdepasse'])));
                $motdepasse_hash = password_hash($motdepasse_clean, PASSWORD_DEFAULT);
                $type_clean = htmlspecialchars(addslashes(trim($_POST['type'])));
                $idutilisateur_clean = htmlspecialchars(addslashes(trim($_POST['idutilisateur'])));
                $idrole_clean = htmlspecialchars(addslashes(trim($_POST['idrole'])));
    
           
            $utilisateur = (new Utilisateur($this->getDB()));
            $result = $utilisateur->creerUtilisateur($nom_clean, $prenom_clean, $adresse_clean, $tel_clean, $email_clean, $motdepasse_hash, $type_clean, $idutilisateur_clean, $idrole_clean);

            if($result){

                $_SESSION['success'] = "Félicitations vous devenez un client avec succès!";
                return $this->view("auth.connexion");
            }
        }
    }
        
}