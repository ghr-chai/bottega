<?php
namespace App\Controllers\Admin;

use App\Models\Marque;
use App\Validation\Validator;
use App\Controllers\Controller;

class AdminMarqueController extends Controller 
{
    public function index(){
       
        $this->isAdmin();
        $marques = (new Marque($this->getDB()))->all();
        return $this->view('admin.marques.index', compact('marques'));
    }

    public function create(){
        $this->isAdmin();
        return $this->view('admin.marques.create');
    }

    public function createMarque(){
        $this->isAdmin();
        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "nommarque" => ["required", "uniqueOnCreateMarque"],
                
            ]);
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'administrateur vers la page de départ
                    return $this->redirect_back();
            }
            

        // créer une instance de notre modéle Marque
        $marque = (new Marque($this->getDB()));      
        $result = $marque->create($_POST);
      
        if($result){

            $_SESSION['success'] = "Cette marque a été ajoutée avec succès.";
            return $this->redirect_to_url("admin/marques");
        }
        
    }
}

    public function edit(int $id){
        $this->isAdmin();
        $marque = (new Marque($this->getDB()))->findById($id);
        return $this->view('admin.marques.edit', compact('marque'));

    }

    public function update(int $id){
        $this->isAdmin();

        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "nommarque" => ["required", "uniqueOnUpdateMarque"],
                
            ]);
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'administrateur vers la page de départ
                    return $this->redirect_back();
            }

        $marque = (new Marque($this->getDB()));
        $result = $marque->update($id, $_POST);

        if($result){

            $_SESSION['success'] = "Cette marque a été modifiée de la liste.";
            return $this->redirect_to_url("admin/marques");
        }

    }
}
    

    public function destroy(int $id){
        $this->isAdmin();
        $marque = (new Marque($this->getDB()));
        $result = $marque->destroy($id);

        if($result){

            $_SESSION['success'] = "Cette marque a été supprimée de la liste.";
            return $this->redirect_to_url("admin/marques");
        }


    }
    
}