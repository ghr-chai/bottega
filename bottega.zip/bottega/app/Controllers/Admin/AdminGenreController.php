<?php
namespace App\Controllers\Admin;

use App\Models\Genre;
use App\Validation\Validator;
use App\Controllers\Controller;

class AdminGenreController extends Controller 
{
    
       


    public function index(){

        $this->isAdmin();
        $genres = (new Genre($this->getDB()))->all();
        return $this->view('admin.genres.index', compact('genres'));
    }

    public function create(){
        $this->isAdmin();
        return $this->view('admin.genres.create');
    }

    public function createGenre(){
        $this->isAdmin();
        if ($_SERVER['REQUEST_METHOD'] === "POST") 
            {
                $validator = new Validator($_POST);

                $errors = $validator->validate([

                    "libellegenre" => ["required", "uniqueOnCreateGenre"],
                    
                ]);
                if($errors){
                    $_SESSION['errors'] = $errors;
    
                        foreach ($_POST as $key => $value) 
                        {
                            $_SESSION['previous_input'][$key] = $value; 
                        }
    
                        // On redirige l'administrateur vers la page de départ
                        return $this->redirect_back();
                }

        // créer une instance de notre modèle Genre
        $genre = (new Genre($this->getDB()));
        $result = $genre->create($_POST);

        if($result){

            $_SESSION['success'] = "Ce genre a été ajouté avec succès.";
            return $this->redirect_to_url("admin/genres");
        }
        
    }}

    public function edit(int $id){
        $this->isAdmin();
        $genre = (new Genre($this->getDB()))->findById($id);
        return $this->view('admin.genres.edit', compact('genre'));

    }

    public function update(int $id){
        $this->isAdmin();
        if ($_SERVER['REQUEST_METHOD'] === "POST") 
            {
                $validator = new Validator($_POST);

                $errors = $validator->validate([

                    "libellegenre" => ["required", "uniqueOnUpdateGenre"],
                   
                ]);
                if($errors){
                    $_SESSION['errors'] = $errors;
    
                        foreach ($_POST as $key => $value) 
                        {
                            $_SESSION['previous_input'][$key] = $value; 
                        }
    
                        // On redirige l'administrateur vers la page de départ
                        return $this->redirect_back();
                }
        $genre = (new Genre($this->getDB()));
        $result = $genre->update($id, $_POST);

        if($result){

            $_SESSION['success'] = "Ce genre a été modifié de la liste.";
            return $this->redirect_to_url("admin/genres");
        }

    }
}
    

    public function destroy(int $id){
        $this->isAdmin();
        $genre = (new Genre($this->getDB()));
        $result = $genre->destroy($id);

        if($result){

            $_SESSION['success'] = "Ce genre a été supprimé de la liste.";
            return $this->redirect_to_url("admin/genres");
        }


    }
    
}