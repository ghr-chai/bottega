<?php
namespace App\Controllers\Admin;

use App\Models\Role;
use App\Validation\Validator;
use App\Controllers\Controller;

class AdminRoleController extends Controller 
{
    public function index(){

        $this->isAdmin();
        $roles = (new Role($this->getDB()))->all();
        return $this->view('admin.roles.index', compact('roles'));
    }

    public function create(){
        $this->isAdmin();
        return $this->view('admin.roles.create');
    }

    public function createRole(){
        $this->isAdmin();

        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "libellerole" => ["required"],
                
            ]);
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'administrateur vers la page de départ
                    return $this->redirect_back();
            }

        // créer une instance de notre modéle Role
        $role = (new Role($this->getDB()));
        $result = $role->create($_POST);

        if($result){

            $_SESSION['success'] = "Ce Rôle a été ajouté avec succès.";
            return $this->redirect_to_url("admin/roles");
        }
        
    }
}

    public function edit(int $id){
        $this->isAdmin();
        $role = (new Role($this->getDB()))->findById($id);
        return $this->view('admin.roles.edit', compact('role'));

    }

    public function update(int $id){
        $this->isAdmin();
        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "libellerole" => ["required"],
                
            ]);
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'administrateur vers la page de départ
                    return $this->redirect_back();
            }

        $role = (new Role($this->getDB()));
        $result = $role->update($id, $_POST);

        if($result){

            $_SESSION['success'] = "Ce Rôle a été modifié de la liste.";
            return $this->redirect_to_url("admin/roles");
        }

    }
}
    

    public function destroy(int $id){
        $this->isAdmin();
        $role = (new Role($this->getDB()));
        $result = $role->destroy($id);

        if($result){

            $_SESSION['success'] = "Ce Rôle a été supprimé de la liste.";
            return $this->redirect_to_url("admin/roles");
        }


    }
    
}