<?php
namespace App\Controllers\Admin;

use PDO;
use App\Models\Genre;
use App\Models\Marque;
use App\Models\Taille;
use App\Models\Article;
use App\Models\Utilisateur;
use App\Controllers\Controller;
use App\Validation\Validator;

class AdminArticleController extends Controller 
{  
    public function index(){

        $this->isAdmin();

        $articles = (new Article($this->getDB()))->all();
        return $this->view('admin.articles.index', compact('articles'));
    }
    //elle va renvoyer le formulaire d'ajout un article
    public function create()
    {
        $this->isAdmin();
        $marques = (new Marque($this->getDB()))->all();
        $utilisateurs = (new Utilisateur($this->getDB()))->all();
        $tailles = (new Taille($this->getDB()))->all();
        $genres = (new Genre($this->getDB()))->all();
       

        return $this->view('admin.articles.create', compact('marques', 'utilisateurs', 'tailles', 'genres'));
    }
    //elle va traiter les données envoyées en Post
    public function createArticle(){
        $this->isAdmin();
        
        if ($_SERVER['REQUEST_METHOD'] === "POST") 
            {
                $validator = new Validator($_POST);

                $errors = $validator->validate([

                    "nomarticle" => ["required", "min:1"],
                    "description" => ["required", "min:10"],
                    "imagechemin" =>["required"],
                    "idmarque" =>["required"],
                    "idutilisateur" =>["required"],
                    "idtaille" =>["required"],
                    "idgenre" =>["required"]
                    
                ]);
                if($errors){
                    $_SESSION['errors'] = $errors;
    
                        foreach ($_POST as $key => $value) 
                        {
                            $_SESSION['previous_input'][$key] = $value; 
                        }
    
                        // On redirige l'administrateur vers la page de départ
                        return $this->redirect_back();
                }

            // créer une instance de notre modéle Article
            $article = (new Article($this->getDB()));
            $result = $article->creerArticle($_POST, $_FILES);

           

            $_SESSION['success'] = "Cet article a été ajouté avec succès.";
            return $this->redirect_to_url("admin/articles");

            
        } 
    } 
    

    public function edit(int $id){
        $this->isAdmin();
        $article = (new Article($this->getDB()))->findById($id);
        
        $marques = (new Marque($this->getDB()))->all();
        $utilisateurs = (new Utilisateur($this->getDB()))->all();
        $tailles = (new Taille($this->getDB()))->all();
        $genres = (new Genre($this->getDB()))->all();
        
        return $this->view('admin.articles.edit', compact('article','marques', 'utilisateurs', 'tailles', 'genres'));

    }

    public function update(int $id){

        $this->isAdmin();
        
        if ($_SERVER['REQUEST_METHOD'] === "POST") 
            {
                $validator = new Validator($_POST);

                $errors = $validator->validate([

                    "nomarticle" => ["required", "min:1"],
                    "description" => ["required", "min:10"],
                    "imagechemin" =>["required"],
                    "idmarque" =>["required"],
                    "idutilisateur" =>["required"],
                    "idtaille" =>["required"],
                    "idgenre" =>["required"]
                    
                ]);
                if($errors){
                    $_SESSION['errors'] = $errors;
    
                        foreach ($_POST as $key => $value) 
                        {
                            $_SESSION['previous_input'][$key] = $value; 
                        }
    
                        // On redirige l'administrateur vers la page de départ
                        return $this->redirect_back();
                }

        $article = (new Article($this->getDB()));
        $result = $article->modifier($id, $_POST, $_FILES);

        if($result){

            $_SESSION['success'] = "Cet article a été modifié de la liste.";
            return $this->redirect_to_url("admin/articles");
        }

    }
}
    

    public function destroy(int $id){
        $this->isAdmin();
        $article = (new Article($this->getDB()));
        $result = $article->destroy($id);

        if($result){

            $_SESSION['success'] = "Cet article a été supprimé de la liste.";
            return $this->redirect_to_url("admin/articles");
        }


    }
    
}