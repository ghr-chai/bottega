<?php
namespace App\Controllers\Admin;

use App\Models\Commande;
use App\Controllers\Controller;

class AdminCommandeController extends Controller 
{
    public function index(){

        $this->isAdmin();

        $commandes = (new Commande($this->getDB()))->all();
        return $this->view('admin.commandes.index', compact('commandes'));
    }

}