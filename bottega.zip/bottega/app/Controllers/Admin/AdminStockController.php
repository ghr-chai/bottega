<?php
namespace App\Controllers\Admin;

use App\Models\Stock;
use App\Models\Article;
use App\Validation\Validator;
use App\Controllers\Controller;

class AdminStockController extends Controller 
{
    public function index(){

       
        $stocks = (new Stock($this->getDB()))->all();
        return $this->view('admin.stocks.index', compact('stocks'));
    }

    public function create(){
      
        $articles = (new Article($this->getDB()))->all();

        return $this->view('admin.stocks.create', compact('articles'));
    }

    public function createStock(){

        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "qtestockee" => ["required", "integer"],
                "qtemin" => ["required", "integer"],
                "qtemax" => ["required", "integer"],
                
            ]);
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'administrateur vers la page de départ
                    return $this->redirect_back();
            }

      
        // créer une instance de notre modéle Stock
        $stock = (new Stock($this->getDB()));
        $result = $stock->create($_POST);

        if($result){

            $_SESSION['success'] = "Ce stock a été ajouté avec succès.";
            return $this->redirect_to_url("admin/stocks");
        }
        
    }
}

    public function edit(int $id){
       
        $articles = (new Article($this->getDB()))->all();
        $stock = (new Stock($this->getDB()))->findById($id);

        return $this->view('admin.stocks.edit', compact('stock', 'articles'));

    }

    public function update(int $id){
        
        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "qtestockee" => ["required", "integer"],
                "qtemin" => ["required", "integer"],
                "qtemax" => ["required", "integer"],
                
            ]);
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'administrateur vers la page de départ
                    return $this->redirect_back();
            }

        $stock = (new Stock($this->getDB()));
        $result = $stock->update($id, $_POST);

        if($result){

            $_SESSION['success'] = "Ce stock a été modifié de la liste.";
            return $this->redirect_to_url("admin/stocks");
        }

    }
}
    

    public function destroy(int $id){
      
        $stock = (new Stock($this->getDB()));
        $result = $stock->destroy($id);

        if($result){

            $_SESSION['success'] = "Ce stock a été supprimé de la liste.";
            return $this->redirect_to_url("admin/stocks");
        }


    }
    
}