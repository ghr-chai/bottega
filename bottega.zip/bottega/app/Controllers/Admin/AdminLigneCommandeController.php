<?php
namespace App\Controllers\Admin;


use App\Models\LigneCommande;
use App\Controllers\Controller;

class AdminLigneCommandeController extends Controller 
{
    public function index(){

        $this->isAdmin();

        $lignescommandes = (new LigneCommande($this->getDB()))->all();
        return $this->view('admin.lignesCommandes.index', compact('lignescommandes'));
    }

}