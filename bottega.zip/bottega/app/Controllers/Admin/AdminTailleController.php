<?php
namespace App\Controllers\Admin;

use App\Models\Taille;
use App\Validation\Validator;
use App\Controllers\Controller;

class AdminTailleController extends Controller 
{   
       
    public function index(){

        $this->isAdmin();
        $tailles = (new Taille($this->getDB()))->all();
        return $this->view('admin.tailles.index', compact('tailles'));
    }

    public function create(){
        $this->isAdmin();
        return $this->view('admin.tailles.create');
    }

    public function createTaille(){
        $this->isAdmin();

        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "volumeflacon" => ["required", "uniqueOnCreateTaille"],
                
            ]);
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'administrateur vers la page de départ
                    return $this->redirect_back();
            }
        // créer une instance de notre modéle Taille
        $taille = (new Taille($this->getDB()));
        $result = $taille->create($_POST);

        if($result){

            $_SESSION['success'] = "Cette taille a été ajoutée avec succès.";
            return $this->redirect_to_url("admin/tailles");
        }
        
    }
}

    public function edit(int $id){
        $this->isAdmin();
        $taille = (new Taille($this->getDB()))->findById($id);
        return $this->view('admin.tailles.edit', compact('taille'));

    }

    public function update(int $id){
        $this->isAdmin();

        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "volumeflacon" => ["required", "uniqueOnUpdateTaille"],
                
            ]);
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'administrateur vers la page de départ
                    return $this->redirect_back();
            }

        
        $taille = (new Taille($this->getDB()));
        $result = $taille->update($id, $_POST);

        if($result){

            $_SESSION['success'] = "Cette taille a été modifiée de la liste.";
            return $this->redirect_to_url("admin/tailles");
        }

    }
}
    

    public function destroy(int $id){
        $this->isAdmin();
        $taille = (new Taille($this->getDB()));
        $result = $taille->destroy($id);

        if($result){

            $_SESSION['success'] = "Cette taille a été supprimée de la liste.";
            return $this->redirect_to_url("admin/tailles");
        }


    }
    
}