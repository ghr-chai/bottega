<?php
namespace App\Controllers\Admin;

use App\Models\Role;
use App\Models\Utilisateur;
use App\Validation\Validator;
use App\Controllers\Controller;

class AdminUtilisateurController extends Controller 
{
   
    public function index(){

        $this->isAdmin();

        $utilisateurs = (new Utilisateur($this->getDB()))->all();
        return $this->view('admin.utilisateurs.index', compact('utilisateurs'));
    }

    public function create(){
        $this->isAdmin();
        $utilisateurs = (new Utilisateur($this->getDB()))->all();
        $roles = (new Role($this->getDB()))->all();

        return $this->view('admin.utilisateurs.create', compact('utilisateurs', 'roles'));
    }

    public function createUtilisateur(){
        $this->isAdmin();

        if ($_SERVER['REQUEST_METHOD'] === "POST") 
            {
                //en appelant la fonction validate ça peut retourner un tableau d'erreurs ou non si oui on le stocke dans $errors.
                $validator = new Validator($_POST);
    
                $errors = $validator->validate([
    
                    "nom" => ["required", "min:2"],
                    "prenom" => ["required", "min:2"],
                    "adresse" =>["required"],
                    "tel" =>["required"],
                    "email" =>["required", "uniqueOnCreateUtilisateur"],
                    "motdepasse" =>["required"],
                    "type" =>["required"]
                    
                ]);
                 if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
                    {
                        $errors['email'] = "Veuillez entrer un email valide.";
                    }
                if($errors){
                    $_SESSION['errors'] = $errors;
    
                        foreach ($_POST as $key => $value) 
                        {
                            $_SESSION['previous_input'][$key] = $value; 
                        }
    
                        // On redirige l'internaute vers la page de départ
                        return $this->redirect_back();
                }
    
                $nom_clean = htmlspecialchars(addslashes(trim($_POST['nom'])));
                $prenom_clean = htmlspecialchars(addslashes(trim($_POST['prenom'])));
                $adresse_clean = htmlspecialchars(addslashes(trim($_POST['adresse'])));
                $tel_clean = htmlspecialchars(addslashes(trim($_POST['tel'])));
                $email_clean = htmlspecialchars(addslashes(trim($_POST['email'])));
                $motdepasse_clean = htmlspecialchars(addslashes(trim($_POST['motdepasse'])));
                $motdepasse_hash = password_hash($motdepasse_clean, PASSWORD_DEFAULT);
                $type_clean = htmlspecialchars(addslashes(trim($_POST['type'])));
                $idutilisateur_clean = htmlspecialchars(addslashes(trim($_POST['idutilisateur'])));
                $idrole_clean = htmlspecialchars(addslashes(trim($_POST['idrole'])));
    

        
        // créer une instance de notre modéle Utilisateur
        $utilisateur = (new Utilisateur($this->getDB()));
        $result = $utilisateur->creerUtilisateur($nom_clean, $prenom_clean, $adresse_clean, $tel_clean, $email_clean, $motdepasse_hash, $type_clean, $idutilisateur_clean, $idrole_clean);

        if($result){

            $_SESSION['success'] = "Cet utilisateur a été ajouté avec succès.";
            return $this->redirect_to_url("admin/utilisateurs");
        }
        
    }
}

    public function edit(int $id){
        $this->isAdmin();
        $utilisateurs = (new Utilisateur($this->getDB()))->all();
        $utilisateur = (new Utilisateur($this->getDB()))->findById($id);
        $roles = (new Role($this->getDB()))->all();
        
        return $this->view('admin.utilisateurs.edit', compact('utilisateur', 'utilisateurs', 'roles'));

    }

    public function update(int $id){
        $this->isAdmin();

        if ($_SERVER['REQUEST_METHOD'] === "POST") 
        {
            $validator = new Validator($_POST);

            $errors = $validator->validate([

                "nom" => ["required", "min:2"],
                "prenom" => ["required", "min:2"],
                "adresse" =>["required"],
                "tel" =>["required"],
                "email" =>["required", "uniqueOnUpdateUtilisateur"],
                "motdepasse" =>["required"],
                "type" =>["required"]
                
            ]);
             if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
                {
                    $errors['email'] = "Veuillez entrer un email valide.";
                }
            if($errors){
                $_SESSION['errors'] = $errors;

                    foreach ($_POST as $key => $value) 
                    {
                        $_SESSION['previous_input'][$key] = $value; 
                    }

                    // On redirige l'internaute vers la page de départ
                    return $this->redirect_back();
            }

            $nom_clean = htmlspecialchars(addslashes(trim($_POST['nom'])));
            $prenom_clean = htmlspecialchars(addslashes(trim($_POST['prenom'])));
            $adresse_clean = htmlspecialchars(addslashes(trim($_POST['adresse'])));
            $tel_clean = htmlspecialchars(addslashes(trim($_POST['tel'])));
            $email_clean = htmlspecialchars(addslashes(trim($_POST['email'])));
            $motdepasse_clean = htmlspecialchars(addslashes(trim($_POST['motdepasse'])));
            $motdepasse_hash = password_hash($motdepasse_clean, PASSWORD_DEFAULT);
            $type_clean = htmlspecialchars(addslashes(trim($_POST['type'])));
            $idutilisateur_clean = htmlspecialchars(addslashes(trim($_POST['idutilisateur'])));
            $idrole_clean = htmlspecialchars(addslashes(trim($_POST['idrole'])));

        
            $utilisateur = (new Utilisateur($this->getDB()));
            $result = $utilisateur->modifierUtilisateur($id, $nom_clean, $prenom_clean, $adresse_clean, $tel_clean, $email_clean, $motdepasse_hash, $type_clean, $idutilisateur_clean, $idrole_clean);

            if($result){

                $_SESSION['success'] = "Cet utilisateur a été modifié de la liste.";
                return $this->redirect_to_url("admin/utilisateurs");
            }

        }

    } 

    public function destroy(int $id){
        $this->isAdmin();
        $utilisateur = (new Utilisateur($this->getDB()));
        $result = $utilisateur->destroy($id);

        if($result){

            $_SESSION['success'] = "Cet utilisateur a été supprimé de la liste.";
            return $this->redirect_to_url("admin/utilisateurs");
        }


    }
    
}