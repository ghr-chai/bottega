<?php
namespace App\Controllers;// déjà définit dans composer.json


use App\Models\Genre;
// use App\Validation\Validator;

use App\Models\Marque;
use App\Models\Taille;

use App\Models\Article;
use App\Models\Utilisateur;
use App\Controllers\Controller;



    class ArticleController extends Controller
    {
    
        public function index()
        {
            $NbrArticlesParPage = 9;
            $currentPageNbr = 1;

            if (isset($_SESSION['boutiqueCurrentPageNbr']))
            {
                $currentPageNbr = intval($_SESSION['boutiqueCurrentPageNbr']);
            }
            if (isset($_GET['page']))
            {
                $currentPageNbr = intval($_GET['page']);
            }

            $article = new Article($this->getDB());
            $articleList = $article->getArticlesParPage((($currentPageNbr-1)*$NbrArticlesParPage), $NbrArticlesParPage);

            $nbrArticles = $article->getNbreArticles();
            $nbrPages = ceil($nbrArticles/$NbrArticlesParPage);

            if($currentPageNbr > $nbrPages)
            {
                $currentPageNbr = $nbrPages;
            }

            $previousPageNbr = $currentPageNbr == 1 ? $currentPageNbr : $currentPageNbr - 1;
            $currentPageNbr = $currentPageNbr;
            $nextPageNbr = $currentPageNbr == $nbrPages ? $currentPageNbr : $currentPageNbr + 1;
            $lastPageNbr = $nbrPages;

            $_SESSION['boutiqueCurrentPageNbr'] = $currentPageNbr;

            return $this->view("boutique.index", compact('articleList', 'previousPageNbr', 'currentPageNbr', 'nextPageNbr', 'lastPageNbr'));
        }


        public function rechercher(){
            

            $_SESSION['boutiqueCurrentPageNbr'] = $currentPageNbr;
            
            $article = new Article($this->getDB());

            $articleList = $article->findByName($_GET["rechercheparfum"]);

            $currentPageNbr = 1;
            return $this->view("boutique.index", compact('articleList', 'currentPageNbr'));
        }

        // on a passé le paramètre $id grâce à notre système de Routing   
        public function show(int $id){
            
            $article = new Article($this->getDB());
            $article = $article->findById($id);

            $marques = (new Marque($this->getDB()))->all();
            $tailles = (new Taille($this->getDB()))->all();
            $genres = (new Genre($this->getDB()))->all();
           
            return $this->view("boutique.show", compact('article','marques', 'tailles', 'genres'));
        }

        public function showCompte(int $id){
            
            $article = new Article($this->getDB());
            $article = $article->findById($id);

            $marques = (new Marque($this->getDB()))->all();
            $tailles = (new Taille($this->getDB()))->all();
            $genres = (new Genre($this->getDB()))->all();
           
            return $this->view("boutique.showCompte", compact('article','marques', 'tailles', 'genres'));
        }

        public function indexCompte(){

            $article = new Article($this->getDB());
            $articles = $article->all();
            $utilisateurs = (new Utilisateur($this->getDB()))->all();
           
            return $this->redirect_to_url("boutique");
        }

        
    }