<?php
namespace App\Controllers;// déjà définit dans composer.json



use App\Models\Article;
use App\Models\Commande;
use App\Models\Utilisateur;
use App\Models\LigneCommande;
use App\Controllers\Controller;



    class LigneCommandeController extends Controller
    {

        public function contenuPanier($idutilisateur)
        {

            $commande = (new Commande($this->getDB()))->getByUtilisateurAndStatus($_SESSION['idUtilisateur'], 
                                                             Commande::EtatEnPreparation);
            if(!$commande)
            {
                $_SESSION['nbreArticles']= 0;       
                return $this->view('boutique.panier');
            }

    
            $lignesCommande = (new LigneCommande($this->getDB()))->
                                     getAllLigneCommandeByCommandeAndDetailsArticles($commande->id);

            $totalArticles =(new LigneCommande($this->getDB()))->getNbreArticlesDeCommandeEnPreparation($commande->id);

            $montantGlobal =(new LigneCommande($this->getDB()))->getMontantGlobalDeCommandeEnPreparation($commande->id);

            if($lignesCommande && $totalArticles ){  

                $_SESSION['nbreArticles']= $totalArticles;
                return $this->view('boutique.panier', compact('lignesCommande', 'montantGlobal') );

                // Vider le panier quand l'échéance de passer commande expire
                $nextWeek = time() + (7 * 24 * 60 * 60);

                    if(date('Y-m-d H:i:s', $nextWeek) && $_SESSION['nbreArticles']!= 0){

                        $result = (new LigneCommande($this->getDB()))->truncate();
                        $_SESSION['nbreArticles']= 0;
                        return $this->view('boutique.panier');
                    }

                
            }else{

                $_SESSION['nbreArticles']= 0;
                
                return $this->view('boutique.panier');

            }
        }

        // Ajouter un article au panier
        // $id : identifiant de l'article
        public function ajouterAuPanier(int $id)
        {

            $article = (new Article($this->getDB()))->findById($id);

            $commande = (new Commande($this->getDB()))->getByUtilisateurAndStatus($_SESSION['idUtilisateur'], Commande::EtatEnPreparation);
            // on va traiter le cas ou la commande existe déjà et on veut ajouter une ligne de commande
            if($commande)
            {
                
                $LigneCommande = (new LigneCommande($this->getDB()))->getLigneCommandeByArticleAndCommande($article->id, $commande->id);

                // si la commande existe et l'article existe déjà on augmente juste la quantité
                if($LigneCommande)
                {
                    $qteCommandee = intval($_POST['qtecommandee']) + intval($LigneCommande->qtecommandee);
                    $result =$LigneCommande->mettreAjour($qteCommandee);
                    if($result){

                        $_SESSION['success'] = "Vous avez commandé ".  $qteCommandee. " parfums " . "de l'article " .$article->nomarticle." avec succès!";

                        $totalArticles =(new LigneCommande($this->getDB()))->getNbreArticlesDeCommandeEnPreparation($commande->id);
                        $_SESSION['nbreArticles']= $totalArticles;

                        return $this->redirect_to_url("boutique/compte/{$id}");
                       
                    }  

                }
                // si la commande existe et l'article n'existe pas on l'ajoute
                else
                {
                    // on crée une nouvelle ligne de commande 
                    $arrayLigneCommande = array(

                        "qtecommandee" => $_POST['qtecommandee'],
                        "prixUnitVente" => $article->prix,
                        "datecreation" => date("Y-m-d H:i:s"),
                        "datemodification" => date("Y-m-d H:i:s"),
                        "idarticle" => $article->id,
                        "idcommande" => $commande->id
                    );
    
                    $ligneCommande= (new LigneCommande($this->getDB()));
    
                    $ligneCommande->create($arrayLigneCommande);
    
                    $AllLigneCommande = (new LigneCommande($this->getDB()))->getAllLigneCommandeByCommande($commande->id);

                    if($AllLigneCommande)
                    {
                        $_SESSION['success'] = "Vous avez ajouté ".  $_POST['qtecommandee']. " parfums " . "de l'article " .$article->nomarticle." avec succès!";

                        $totalArticles =(new LigneCommande($this->getDB()))->getNbreArticlesDeCommandeEnPreparation($commande->id);
                        $_SESSION['nbreArticles']= $totalArticles;

                        return $this->redirect_to_url("boutique/compte/{$id}");
                            
                           
                    }
                }


            }
            //dans le cas ou la commande n'existe pas on va la créer d'abord et ajouter une ligne de commande
            else
            {
                $arrayCommande = array(

                    "libellecommande" =>"Achat parfum(s)",
                    "adresselivraison" => "Inexistante pour le moment",
                    "status" => Commande::EtatEnPreparation,
                    "datecreation" =>date("Y-m-d H:i:s"),
                    "datemodification" =>date("Y-m-d H:i:s"),
                    "idutilisateur" => $_SESSION ['idUtilisateur']
                );
                //Ajouter une commande
                $commande= (new Commande($this->getDB()));

                // on récupère l'id de la nouvelle commande crée
                $idCommande = $commande->create($arrayCommande);
                
                //Ajouter une ligne commande
                $arrayLigneCommande = array(

                    
                    "qtecommandee" => $_POST['qtecommandee'],
                    "prixUnitVente" => $article->prix,
                    "datecreation" => date("Y-m-d H:i:s"),
                    "datemodification" => date("Y-m-d H:i:s"),
                    "idarticle" => $article->id,
                    "idcommande" => $idCommande
                );

                $ligneCommande= (new LigneCommande($this->getDB()));

                $ligneCommande->create($arrayLigneCommande);

                $_SESSION['success'] = "Vous avez commandé ".  $_POST['qtecommandee']. " parfums " . "de l'article " .$article->nomarticle." avec succès!";

                $totalArticles =(new LigneCommande($this->getDB()))->getNbreArticlesDeCommandeEnPreparation($idCommande);
                $_SESSION['nbreArticles']= $totalArticles;

                return $this->redirect_to_url("boutique/compte/{$id}");
                
               
            }

        }    
        
        // Modification de la quantité dans le panier
        public function modifier($id){

            $article = (new Article($this->getDB()))->findById($id);

            $commande = (new Commande($this->getDB()))->getByUtilisateurAndStatus($_SESSION['idUtilisateur'], Commande::EtatEnPreparation);

            $LigneCommande = (new LigneCommande($this->getDB()))->getLigneCommandeByArticleAndCommande($article->id, $commande->id);

            // si la commande existe et l'article existe déjà on augmente juste la quantité
            $qteCommandee = intval($_GET['qtecommandee']);

            $result =$LigneCommande->mettreAjour($qteCommandee);

            if($result){

                $totalArticles =(new LigneCommande($this->getDB()))->getNbreArticlesDeCommandeEnPreparation($commande->id);
                
                $_SESSION['nbreArticles']= $totalArticles;
                
                $montantGlobal =(new LigneCommande($this->getDB()))->getMontantGlobalDeCommandeEnPreparation($commande->id);
                
                return $this->redirect_to_url("panier/{$_SESSION['idUtilisateur']}");
                       
            }  
        }

        public function delete(int $id)
        {
            // $article = (new Article($this->getDB()))->findById($id);

            $commande = (new Commande($this->getDB()))->getByUtilisateurAndStatus($_SESSION['idUtilisateur'], Commande::EtatEnPreparation);
            
            $lignesCommande = (new LigneCommande($this->getDB()))->
                                     getAllLigneCommandeByCommandeAndDetailsArticles($commande->id);

            $result = (new LigneCommande($this->getDB()))->destroy($id);
            
            if($result){
    
               

                $totalArticles =(new LigneCommande($this->getDB()))->getNbreArticlesDeCommandeEnPreparation($commande->id);
                
                $_SESSION['nbreArticles']= $totalArticles;

                if($totalArticles == 0){

                    $_SESSION['success'] = "Aucun article à supprimer le panier est vide.";
                    
                    // return $this->redirect_to_url("espaceReserve");

                    return $this->redirect_to_url("panier/{$_SESSION['idUtilisateur']}");
                }
                else{

                    $_SESSION['success'] = "Cet article a été supprimé du panier.";
                    
                    return $this->redirect_to_url("panier/{$_SESSION['idUtilisateur']}");
                }
               
            }
            
        }
        
    }