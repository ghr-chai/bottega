<?php
namespace App\Models;

class Role extends Model{

    protected $table = 'roles';

    public function create(array $data){

        // la méthode create va créer un enregistrement
        parent::create($data);
        // on récupère la connection , on se connecte à la BD et on récupère le dernier id (AI) pour l'associer au nouveau enregistrement
        $id = $this->db->getPDO()->LastInsertId();
        return true;
    }

}