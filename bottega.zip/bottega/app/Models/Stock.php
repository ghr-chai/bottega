<?php
namespace App\Models;

use PDO;

class Stock extends Model{

    protected $table = 'stocks';

    public function create(array $data){

        // la méthode create va créer un enregistrement
        parent::create($data);
        // on récupère la connection , on se connecte à la BD et on récupère le dernier id (AI) pour l'associer au nouveau enregistrement
        $id = $this->db->getPDO()->LastInsertId();
        return true;
    }

    public function getNomArticle($id)
    {
        $req = $this->db->getPDO()->prepare("SELECT articles.nomarticle FROM articles JOIN stocks ON stocks.idarticle=articles.id WHERE stocks.id=:id");
        $req->bindValue(":id",intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }

}