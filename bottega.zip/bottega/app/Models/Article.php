<?php
namespace App\Models;


use PDO;

class Article extends Model{

    protected $table = 'articles';

    public function creerArticle(array $data, array $fichier)
    {
        // on récupère l'image envoyée depuis le formulaire du create
        $image = $fichier['imagechemin'];
        // on crée  un nom complet pour l'image
        // afin de ne pas avoir 2 images qui auront le même nom
        $imagechemin_nom_complet = "/bottega/public/uploads/articles/images/" . time() . "_" . rand(0, 99999999) . $image['name'];

        $req = $this->db->getPDO()->prepare("INSERT INTO articles (nomarticle, description, imagechemin, prix, datecreation, datemodification, idmarque, idutilisateur, idtaille, idgenre) VALUES(:nomarticle, :description, :imagechemin, :prix, now(), null, :idmarque, :idutilisateur, :idtaille, :idgenre )");
     
        $req->bindValue(":nomarticle", $data['nomarticle'], PDO::PARAM_STR);
        $req->bindValue(":description", $data['description'], PDO::PARAM_STR);
        $req->bindValue(":imagechemin", $imagechemin_nom_complet, PDO::PARAM_STR);
        $req->bindValue(":prix", $data['prix'], PDO::PARAM_STR);
        $req->bindValue(":idmarque", $data['idmarque'], PDO::PARAM_INT);
        $req->bindValue(":idutilisateur", $data['idutilisateur'], PDO::PARAM_INT);
        $req->bindValue(":idtaille", $data['idtaille'], PDO::PARAM_INT);
        $req->bindValue(":idgenre", $data['idgenre'], PDO::PARAM_INT);

        $result= $req->execute();
        $req->closeCursor();

        //Je déplace l'image qui sera ds le dossier public/uploads/articles/images
        if(move_uploaded_file($image['tmp_name'], $_SERVER['DOCUMENT_ROOT'].$imagechemin_nom_complet)){

            return $result;
        }
    }

    public function modifier(int $id, array $data, array $fichier){

        $image = $fichier['imagechemin'];
       
        $imagechemin_nom_complet = "/bottega/public/uploads/articles/images/" . time() . "_" . rand(0, 99999999) . $image['name'];

        // pour supprimer l'image à modifier du dossier uploads
        // unlink($imagechemin_nom_complet); 
        
        $req = $this->db->getPDO()->prepare("UPDATE articles SET nomarticle=:nomarticle, description=:description, imagechemin=:imagechemin, prix=:prix, idmarque=:idmarque, idutilisateur=:idutilisateur, idtaille=:idtaille, idgenre=:idgenre WHERE id=:id");
        
        $req->bindValue(":id", $id, PDO::PARAM_INT);
        $req->bindValue(":nomarticle", $data['nomarticle'], PDO::PARAM_STR);
        $req->bindValue(":description", $data['description'], PDO::PARAM_STR);
        $req->bindValue(":imagechemin", $imagechemin_nom_complet, PDO::PARAM_STR);
        $req->bindValue(":prix", $data['prix'], PDO::PARAM_INT);
        $req->bindValue(":idmarque", $data['idmarque'], PDO::PARAM_INT);
        $req->bindValue(":idutilisateur", $data['idutilisateur'], PDO::PARAM_INT);
        $req->bindValue(":idtaille", $data['idtaille'], PDO::PARAM_INT);
        $req->bindValue(":idgenre", $data['idgenre'], PDO::PARAM_INT);

        $result= $req->execute();
        $req->closeCursor();

        if (move_uploaded_file($image['tmp_name'], $_SERVER['DOCUMENT_ROOT'].$imagechemin_nom_complet) ){
          
            return $result;

        }
    }
        
   
    public function getNomMarque($id)
    {
        $req = $this->db->getPDO()->prepare("SELECT marques.nommarque FROM marques JOIN articles ON articles.idmarque=marques.id WHERE articles.id=:id");
        $req->bindValue(":id",intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }

    public function getNomUtilisateur($id)
    {
        $req = $this->db->getPDO()->prepare("SELECT utilisateurs.prenom FROM utilisateurs JOIN articles ON articles.idutilisateur=utilisateurs.id WHERE articles.id=:id");
        $req->bindValue(":id",intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }
    public function getVolumeFlacon($id)
    {
        $req = $this->db->getPDO()->prepare("SELECT tailles.volumeflacon FROM tailles JOIN articles ON articles.idtaille=tailles.id WHERE articles.id=:id");
        $req->bindValue(":id",intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }
    public function getGenre($id)
    {
        $req = $this->db->getPDO()->prepare("SELECT genres.libellegenre FROM genres JOIN articles ON articles.idgenre=genres.id WHERE articles.id=:id");
        $req->bindValue(":id",intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }

    
    public function findByName(string $nomarticle){

        // return $this->query("SELECT * FROM  articles WHERE nomarticle= ?", [$id], true);
        $nomarticle= htmlspecialchars($nomarticle);

        $req = $this->db->getPDO()->prepare("SELECT marques.nommarque, genres.libellegenre, 
        tailles.volumeflacon, articles.* 
        from marques 
        join articles on marques.id = articles.idmarque 
        join tailles on tailles.id = articles.idtaille  
        join genres on genres.id = articles.idgenre 
        WHERE nomarticle like '%".$nomarticle."%'");

        $req->setFetchMode(PDO::FETCH_CLASS, get_class($this), [$this->db]);
        $req->execute();
        $data = $req->fetchAll();
        $req->closeCursor();

        return $data;
    }  

    public function getNbreArticles(){

        // on récupère le nombre d'articles en total dans la BD
        $req = $this->db->getPDO()->prepare("SELECT COUNT(id) AS nbreArticles FROM articles");
        $req->execute();
        $data = $req->fetchColumn();
        $req->closeCursor();
        return $data;
    }


        public function getArticlesParPage($offset,$limit){
           
        $offset=(int) $offset;// à partir de quel article on va afficher
        $limit=(int) $limit;// combien d'articles on veut afficher
        
        $req = $this->db->getPDO()->prepare("SELECT * FROM articles ORDER BY datecreation DESC LIMIT :offset, :size ");
        $req->setFetchMode(PDO::FETCH_CLASS, get_class($this), [$this->db]);
        $req->bindParam(':offset', $offset, PDO::PARAM_INT);
        $req->bindParam(':size', $limit, PDO::PARAM_INT);
        $req->execute();
        $data = $req->fetchAll();
        
        return $data;


    }     
    
}

    

    

