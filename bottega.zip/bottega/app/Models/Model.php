<?php
namespace App\Models;

// use stdClass: on veut pas retourner une classe neutre mais plutôt un Model :setfetchMode;
use PDO;
use Database\Dbconnection;
// on a passé la classe Model en abstract car elle ne sera jamais instanciée
abstract class Model{
    // cette classe aura un attribut protégé $db car la connection on l'a ferait que au sein de leurs classes enfants
    protected $db;
    // cet attribut est null dans la classe Model mais il va prendre des valeurs selon le nom de la table de la classe enfant concernée de façon dynamique
    protected $table;

    // injection de dépendances: on appelle une fonction constructrice et elle attend une connection de type Dbconnection et on stocke ma connection à la base de données
    public function __construct(Dbconnection $db){

        if(session_status() === PHP_SESSION_NONE){
            session_start();
        }

        $this->db = $db;
    }
    // public et non protected car all() est appelé dans les controllers aussi et non pas seulement aux enfants du model
    public function all() : array{
        // $stmt=$this->db->getPDO()->query("SELECT * FROM {$table} ORDER BY datecreation DESC");
        // return $stmt->fetchAll();

        return $this->query("SELECT * FROM {$this->table} ORDER BY datecreation DESC");
        
    }

    public function findById(int $id): Model{
        // $stmt=$this->db->getPDO()->prepare("SELECT * FROM {$table} WHERE id=?");
        // execute()en sql c'est une fonction qui associe le résultat à un tableau, elle attend un tableau avec le paramètre qui sera remplacer dans le ? qui est $id
        // $stmt->execute([$id]);
        // return $stmt->fetch();

        return $this->query("SELECT * FROM  {$this->table} WHERE id= ?", [$id], true);

    }  

    
    public function create(array $data){
        
        //on créé une variable qui sera la première parenthèse de la requête INSERT INTO définit au début une chaîne de caractères vide
        $firstParenthesis = "";
        //on créé une variable qui sera la deuxième parenthèse de la requête INSERT INTO définit au début une chaîne de caractères vide
        $secondParenthesis = "";
        //$i qui démarrera avec 1 qui représente la première boucle, lorsque $i arrive à count($data) se sera la dernière boucle
        $i = 1;
        //on va faire un foreach sur $data(dans notre cas sera $_POST) et on va récupérer les clés qu'on va les utiliser pour construire notre requête sql 
       foreach ($data as $key =>$value) {
            //$comma égal à un espace si $i est égale à la dernière boucle du tableau $data, sinon on fait une virgule et un espace
            $comma = $i ===count($data) ? " " : ', ';
            // on va accumuler .= les valeurs à chaque fois qu'on boucle
            $firstParenthesis .= "{$key}{$comma}";
            // de même que la première parenthèse on va accumuler .= les valeurs à chaque fois qu'on boucle sauf on ajoute les ":" puisque se sont des paramètres nommés
            $secondParenthesis .= ":{$key}{$comma}";
            // on va incrémenter i à chaque fois qu'on va faire une boucle
            $i++;
       }
        // var_dump($firstParenthesis, $secondParenthesis ); die();

       return $this->query("INSERT INTO {$this->table} ($firstParenthesis) VALUES ($secondParenthesis)", $data);

    }  
    // fonction update a besoin de $id comme premier paramètre et un deuxième paramètre $data qui est un tableau de données exemple $_POST
    public function update(int $id, array $data){

         // mettre à jour les champs de nos différentes tables dynamiquement
         //on définit au début une partie de notre requête sql une chaîne de caractères vide
        $sqlRequestPart = "";
        //$i qui démarrera avec 1 qui représente la première boucle
        $i = 1;
        // on fait un foreach pour pouvoir céder à ce tableau des données $data qui contient comme clés $key les noms des colonnes de la table en BD
         foreach ($data as $key => $value){
            //$comma égal à un espace si $i est égale à la dernière boucle du tableau $data, sinon on fait une virgule et un espace
             $comma = $i ===count($data) ? " " : ', ';
             //on va rajouter au fur et à mesure que ça boucle les noms des colonnes respectivement
             $sqlRequestPart .= "{$key} = :{$key}{$comma}";
             // on va incrémenter i à chaque fois qu'on va faire une boucle
             $i++;
        }
        // var_dump($sqlRequestPart); die();

        $data['id'] = $id;
        // le deuxième paramètre de la fonction query c'est un tableau $data dans ce cas et non un entier $id
        return $this->query("UPDATE {$this->table} SET {$sqlRequestPart} WHERE id=:id", $data);


    }

    public function destroy(int $id){

       return $this->query("DELETE  FROM  {$this->table} WHERE id= ?", [$id]);
          
    } 

    // Vider le panier quand l'échéance de passer commande expire
    public function truncate(){

        return $this->query("TRUNCATE {$this->table}");
           
     } 
    
    // query c'est une fonction qui permet de faire une requête sql que se soit query() ou prepare() selon le besoin, le premier argument $sql est notre requête sql, le deuxième argument $param normalement ça sera $id (et on fait prepare(),execute()) et par défaut est null (et on fait query()seulement), le troisième argument $single si true on fait fetch(), si null par défaut on fait fetchALL();
    public function query(string $sql, array $param = null, bool $single = null)
    {
        // $method est query() si $param est null sinon est prepare()
        $method = is_null ($param) ? 'query' : 'prepare';
        // strpos cherche la position de la première occurence (répétition du mot)dans notre requête
        if(strpos($sql, 'DELETE') === 0 || strpos($sql, 'UPDATE') === 0 || strpos($sql, 'INSERT') === 0){

            $stmt = $this->db->getPDO()->$method($sql);
       
            $stmt->setFetchMode(PDO::FETCH_CLASS, get_class($this), [$this->db]);

            return $stmt->execute($param);
            //on n'a pas besoin de faire un fetch , ces 3 actions delete, update ou insert touchent seulement la BD

        }
        // $fetch est fetchAll si $single est null sinon $single est true et $fetch est fetch()
        $fetch = is_null ($single) ? 'fetchAll' : 'fetch';

        $stmt = $this->db->getPDO()->$method($sql);
        // pour récupérer la classe en cours
        $stmt->setFetchMode(PDO::FETCH_CLASS, get_class($this), [$this->db]);

        if($method === 'query'){
            //$fetch() = fetchAll()
            return $stmt->$fetch();
        }
        // $method ==='prepare'
        else{

            $stmt->execute($param);
            //$fetch() = fetch()
            return $stmt->$fetch();
        }
    }
    








    

}