<?php
namespace App\Models;

use PDO;

class Marque extends Model{

    private $errors;
    protected $table = 'marques';

    public function create(array $data){

        // la méthode create va créer un enregistrement
        parent::create($data);
        // on récupère la connection , on se connecte à la BD et on récupère le dernier id (AI) pour l'associer au nouveau enregistrement
        $id = $this->db->getPDO()->LastInsertId();
        return true;
    }

    
        


}