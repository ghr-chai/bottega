<?php
namespace App\Models;

use PDO;
use App\Models\Article;

class LigneCommande extends Model{

    protected $table = 'lignecommande';

    public function create(array $data){

        // la méthode create va créer un enregistrement
        parent::create($data);
        // on récupère la connection , on se connecte à la BD et on récupère le dernier id (AI) pour l'associer au nouveau enregistrement
        $id = $this->db->getPDO()->LastInsertId();
        return true;
    }
 
    public function getNomArticle($id){

        $req = $this->db->getPDO()->prepare("SELECT articles.nomarticle FROM articles JOIN lignecommande ON lignecommande.idarticle=articles.id WHERE lignecommande.id=:id");
        $req->bindValue(":id", intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }

    }

    public function getAllLigneCommandeByCommandeAndDetailsArticles($id)
    {
        $data = $this->query("SELECT articles.nomarticle, lignecommande.* FROM lignecommande JOIN articles on articles.id= lignecommande.idarticle WHERE idcommande = ?", [$id]);
        return $data;

    }

    public function getAllLigneCommandeByCommande($id)
    {
        $data = $this->query("SELECT * FROM lignecommande WHERE idcommande = ?", [$id]);
        return $data;

    }


    public function getAllLigneCommandeByClient($id)
    {
        $data = $this->query("SELECT commandes.libellecommande, lignecommande.qtecommandee, lignecommande.prixunitvente FROM commandes JOIN lignecommande on commandes.id=lignecommande.idcommande WHERE idutilisateur = ?", [$id]);
        return $data;

    }

    public function getLigneCommandeByArticleAndCommande($idarticle, $idcommande)
    {
        $requete = $this->db->getPDO()->prepare("SELECT * FROM lignecommande WHERE idarticle=:idarticle AND idcommande=:idcommande");
        
        $requete->setFetchMode(PDO::FETCH_CLASS, get_class($this), [$this->db]);

        $requete->bindValue(":idarticle",$idarticle, PDO::PARAM_INT);
        $requete->bindValue(":idcommande",$idcommande, PDO::PARAM_INT);
        $requete->execute();
        $row = $requete->rowCount();
        // var_dump($row); die(); 
        if ($row >= 1) 
        {
            $data = $requete->fetch();
            $requete->closeCursor();
            return $data;
        }
        else
        {
            $requete->closeCursor();
            return false;
        }
    }



    public function mettreAjour($qtecommandee)
    {
            $req = $this->db->getPDO()->prepare("UPDATE lignecommande SET qtecommandee=:qtecommandee WHERE id=:id");
            // on a récupéré déjà l'id de l'instance LingneCommande en cours
            $req->bindValue(":id", $this->id, PDO::PARAM_INT);
            $req->bindValue(":qtecommandee", $qtecommandee, PDO::PARAM_INT);
           
            $result= $req->execute();
            $req->closeCursor();
            return $result;
    }

    public function getMontantGlobalDeCommandeEnPreparation($id){

        $req = $this->db->getPDO()->prepare("SELECT SUM(qtecommandee*prixunitvente) AS montantglobal FROM lignecommande JOIN commandes ON lignecommande.idcommande=commandes.id WHERE commandes.id=:id AND commandes.status=1 ");
        $req->bindValue(":id", intval($id), PDO::PARAM_INT);
        $row=$req->execute();

        if ($row > 0) 
        {
            $data = $req->fetchColumn();
            $req->closeCursor();
            return $data; 
            
        }
        else
        {
            $req->closeCursor();
            return 0;
        }

    }

    public function getNbreArticlesDeCommandeEnPreparation($id)
    {
        $req = $this->db->getPDO()->prepare("SELECT SUM(qtecommandee) AS nbrearticles FROM lignecommande JOIN commandes ON lignecommande.idcommande=commandes.id WHERE commandes.id=:id AND commandes.status=1 ");
        $req->bindValue(":id", intval($id), PDO::PARAM_INT);
        $row=$req->execute();

        
        if ($row > 0) 
        {
            $data = $req->fetchColumn();
            $req->closeCursor();
            return $data; 
            
        }
        else
        {
            $req->closeCursor();
            return 0;
        }
    }

       

}

    

    




  



    
