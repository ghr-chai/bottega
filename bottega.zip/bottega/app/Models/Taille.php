<?php
namespace App\Models;

class Taille extends Model{

    protected $table = 'tailles';

    public function create(array $data){

        // la méthode create va créer un enregistrement
        parent::create($data);
        // on récupère la connection , on se connecte à la BD et on récupère le dernier id (AI) pour l'associer au nouveau enregistrement
        $id = $this->db->getPDO()->LastInsertId();
        return true;
    }

}