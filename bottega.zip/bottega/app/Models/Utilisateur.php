<?php
namespace App\Models;

use PDO;

class Utilisateur extends Model{

    protected $table = 'utilisateurs';

    public function creerUtilisateur($nom_clean, $prenom_clean, $adresse_clean, $tel_clean, $email_clean, $motdepasse_hash, $type_clean, $idutilisateur_clean, $idrole_clean){

        $req = $this->db->getPDO()->prepare("INSERT INTO utilisateurs (nom, prenom, adresse, tel, email, motdepasse, type, datecreation, datemodification, idutilisateur, idrole) VALUES(:nom, :prenom, :adresse, :tel, :email, :motdepasse, :type, now(), null, :idutilisateur, :idrole)");
     
        $req->bindValue(":nom", $nom_clean, PDO::PARAM_STR);
        $req->bindValue(":prenom", $prenom_clean, PDO::PARAM_STR);
        $req->bindValue(":adresse", $adresse_clean, PDO::PARAM_STR);
        $req->bindValue(":tel", $tel_clean, PDO::PARAM_STR);
        $req->bindValue(":email", $email_clean, PDO::PARAM_STR);
        $req->bindValue(":motdepasse", $motdepasse_hash, PDO::PARAM_STR);
        $req->bindValue(":type", $type_clean, PDO::PARAM_STR);
        $req->bindValue(":idutilisateur", $idutilisateur_clean, PDO::PARAM_INT);
        $req->bindValue(":idrole", $idrole_clean, PDO::PARAM_INT);

        $result= $req->execute();
        $req->closeCursor();

        return $result;

    }

    public function modifierUtilisateur(int $id, $nom_clean, $prenom_clean, $adresse_clean, $tel_clean, $email_clean, $motdepasse_hash, $type_clean, $idutilisateur_clean, $idrole_clean){

        
        $req = $this->db->getPDO()->prepare("UPDATE utilisateurs SET nom=:nom, prenom=:prenom, adresse=:adresse, tel=:tel, email=:email, motdepasse=:motdepasse, type=:type, idutilisateur=:idutilisateur, idrole=:idrole WHERE id=:id");
        
        $req->bindValue(":id", $id, PDO::PARAM_INT);
        $req->bindValue(":nom", $nom_clean, PDO::PARAM_STR);
        $req->bindValue(":prenom", $prenom_clean, PDO::PARAM_STR);
        $req->bindValue(":adresse", $adresse_clean, PDO::PARAM_STR);
        $req->bindValue(":tel", $tel_clean, PDO::PARAM_STR);
        $req->bindValue(":email", $email_clean, PDO::PARAM_STR);
        $req->bindValue(":motdepasse", $motdepasse_hash, PDO::PARAM_STR);
        $req->bindValue(":type", $type_clean, PDO::PARAM_STR);
        $req->bindValue(":idutilisateur", $idutilisateur_clean, PDO::PARAM_INT);
        $req->bindValue(":idrole", $idrole_clean, PDO::PARAM_INT);
        $result= $req->execute();
        $req->closeCursor();
        
        return $result;

           
    }

    public function getNomUtilisateur($id)
    {
                                                            
        $req = $this->db->getPDO()->prepare("SELECT u1.prenom FROM utilisateurs as u1 INNER JOIN utilisateurs as u2 ON u2.idutilisateur = u1.id WHERE u2.id=:id");
        $req->bindValue(":id",intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }

    public function getRole($id)
    {
                                                            
        $req = $this->db->getPDO()->prepare("SELECT roles.libellerole FROM roles JOIN utilisateurs ON utilisateurs.idrole=roles.id WHERE utilisateurs.id=:id");
        $req->bindValue(":id",intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }

    public function getByEmail(string $email): Utilisateur{

        return $this->query("SELECT * FROM {$this->table} WHERE email= ?", [$email], true);
  
    }

    public function getClients()
    {
        $req =$this->db->getPDO()->prepare("SELECT utilisateurs.nom, utilisateurs.prenom FROM utilisateurs WHERE type ='client'");
        $req->execute();

        $data = $req->fetchAll();
        $req->closeCursor();
        return $data;                                                   
        
    }

    public function chercherEmail(string $email){

        $req =$this->db->getPDO()->prepare("SELECT utilisateurs.email FROM utilisateurs WHERE email =:email");
        $req->bindValue(":email",$email, PDO::PARAM_STR);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }

}