<?php
namespace App\Models;

use PDO;

class Commande extends Model{

    const EtatEnPreparation = 1; 
    const EtatEnCours = 2; 
    const EtatLivree = 3; 
    const EtatAnnulee = 4; 

    protected $table = 'commandes';

    public function create(array $data){

        // la méthode create va créer un enregistrement
        parent::create($data);
        // on récupère la connection , on se connecte à la BD et on récupère le dernier id (AI) pour l'associer au nouveau enregistrement
        $id = $this->db->getPDO()->LastInsertId();
        // on récupère le id commande pour l'insérer dans la ligne de commande
        return $id;
    }

    // $idutilisateur : identifiant de l'utilisateur
    // $status : état de la commande
    public function getByUtilisateurAndStatus($idutilisateur, $status)
    {

        // $data = $this->query("SELECT * FROM commandes WHERE idutilisateur = ? AND status= ?");
        // $data->setFetchMode(PDO::FETCH_CLASS, get_class($this), [$this->db]);
        // return $data;




        $requete = $this->db->getPDO()->prepare("SELECT * FROM commandes WHERE commandes.idutilisateur = :idutilisateur AND commandes.status= :status");
        
        $requete->setFetchMode(PDO::FETCH_CLASS, get_class($this), [$this->db]);

        $requete->bindValue(":idutilisateur",$idutilisateur, PDO::PARAM_INT);
        $requete->bindValue(":status",$status, PDO::PARAM_INT);
        $requete->execute();
        $row = $requete->rowCount();

        if ($row >= 1) 
        {
            $data = $requete->fetch();
            $requete->closeCursor();
            return $data;

        }
        else
        {
            $requete->closeCursor();
            return false;
        }
    }

    public function mettreAjourStatusEtAdresseLivraison(string $adresselivraison, int $status, int $id)
    {
            $req = $this->db->getPDO()->prepare("UPDATE commandes SET adresselivraison=:adresselivraison, status=:status WHERE id=:id");
           
            $req->bindValue(":adresselivraison", $adresselivraison, PDO::PARAM_STR);
            $req->bindValue(":status", $status, PDO::PARAM_INT);
            $req->bindValue(":id", $id, PDO::PARAM_INT);
            $req->execute();
            $req->closeCursor();
           
    }

    public function getNomClient($id)
    {
        $req = $this->db->getPDO()->prepare("SELECT CONCAT (utilisateurs.prenom,' ', utilisateurs.nom) AS client FROM utilisateurs JOIN commandes ON commandes.idutilisateur=utilisateurs.id WHERE commandes.id=:id");
        $req->bindValue(":id",intval($id), PDO::PARAM_INT);
        $req->execute();
        $row = $req->rowCount();
        // var_dump($row); die(); 
        if ($row == 1) 
        {
            $data = $req->fetch();
            $req->closeCursor();
            return $data;
        }
        else
        {
            $req->closeCursor();
            return false;
        }
    }

}
