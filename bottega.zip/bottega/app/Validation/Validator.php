<?php

namespace App\Validation;

// use Database\Dbconnection;

use PDO;


    class Validator 
    {
        private $_post;
        private $errors;
       
        //à la construction on va passer un tableau qui sont les données $_post en réalité c'est $_POST
        public function __construct($_post)
        {
            //dans $_post on va stocker les données qu'on a reçu à la construction
            $this->_post = $_post;
           
        }

        //on va créer une fonction validate qui prend en paramètre un tableau de règles
        public function validate(array $validation_tab)
        {
            //on va boucler sur le tableau de règles $validation_tab et on va voir si la ou les clés $name_input de ce tableau existent aussi dans le tableau $_POST
            foreach ($validation_tab as $name_input => $rules) 
            {
                //on fait une vérification, si cette clé $name_input existe dans le tableau $_post c'est à dire on a bien vérifié que la colonne existe
                if (array_key_exists($name_input, $this->_post)) 
                {
                    //on fait une boucle sur $rules ,c'est à dire une fois on a vérifié l'existence de la colonne, on va vérifier ces données sont valables ou pas.
                    foreach ($rules as $rule) 
                    {
                        if ($rule === "required") 
                        {
                            $this->required($name_input, $this->_post[$name_input]);
                        }
                        else if($rule === "string")
                        {
                            $this->string($name_input, $this->_post[$name_input]);
                        }
                        else if(substr($rule, 0, 3) === "min")
                        {
                            $this->min($name_input, $this->_post[$name_input], $rule);
                        }
                        else if($rule === "integer")
                        {
                            $this->integer($name_input, $this->_post[$name_input]);
                        }
                        else if(substr($rule, 0, 20) === "uniqueOnCreateMarque")
                        {
                            $this->uniqueOnCreateMarque($name_input, $this->_post[$name_input], $rule);
                        } 
                        else if(substr($rule, 0, 20) === "uniqueOnUpdateMarque")
                        {
                            $this->uniqueOnUpdateMarque($name_input, $this->_post[$name_input], $rule);
                        }  
                        else if(substr($rule, 0, 20) === "uniqueOnCreateTaille")
                        {
                            $this->uniqueOnCreateTaille($name_input, $this->_post[$name_input], $rule);
                        } 
                        else if(substr($rule, 0, 20) === "uniqueOnUpdateTaille")
                        {
                            $this->uniqueOnUpdateTaille($name_input, $this->_post[$name_input], $rule);
                        }  
                        else if(substr($rule, 0, 19) === "uniqueOnCreateGenre")
                        {
                            $this->uniqueOnCreateGenre($name_input, $this->_post[$name_input], $rule);
                        } 
                        else if(substr($rule, 0, 19) === "uniqueOnUpdateGenre")
                        {
                            $this->uniqueOnUpdateGenre($name_input, $this->_post[$name_input], $rule);
                        }  
                        else if(substr($rule, 0, 25) === "uniqueOnCreateUtilisateur")
                        {
                            $this->uniqueOnCreateUtilisateur($name_input, $this->_post[$name_input], $rule);
                        } 
                        else if(substr($rule, 0, 25) === "uniqueOnUpdateUtilisateur")
                        {
                            $this->uniqueOnUpdateUtilisateur($name_input, $this->_post[$name_input], $rule);
                        }  
                    }
                }
            }

            return $this->getErrors();
        }
        
        public function uniqueOnCreateMarque($name_input, $value, $rule)
        {
            $dsn = 'mysql:dbname=bottega;host=127.0.0.1;';
            $user = 'root';
            $password = '';


            $db = new PDO($dsn, $user, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
           
            $req = $db->prepare("SELECT * FROM marques WHERE nommarque=:nommarque");
            $req->bindValue(":nommarque", $value, PDO::PARAM_STR);
            $req->execute();
            $row = $req->rowCount();
            if($row == 1)
            {
                $data = $req->fetch();
                $req->closeCursor();
                $this->errors[$name_input][] = "Cette valeur existe déjà, veuillez en choisir une autre.";
            }
            else
            {
                $req->closeCursor();
                return false;
            }

            
    }

    public function uniqueOnCreateGenre($name_input, $value, $rule)
        {
            $dsn = 'mysql:dbname=bottega;host=127.0.0.1;';
            $user = 'root';
            $password = '';


            $db = new PDO($dsn, $user, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
           
            $req = $db->prepare("SELECT * FROM genres WHERE libellegenre=:libellegenre");
            $req->bindValue(":libellegenre", $value, PDO::PARAM_STR);
            $req->execute();
            $row = $req->rowCount();
            if($row == 1)
            {
                $data = $req->fetch();
                $req->closeCursor();
                $this->errors[$name_input][] = "Cette valeur existe déjà, veuillez en choisir une autre.";
            }
            else
            {
                $req->closeCursor();
                return false;
            }

            
    }

    public function uniqueOnCreateTaille($name_input, $value, $rule)
        {
            $dsn = 'mysql:dbname=bottega;host=127.0.0.1;';
            $user = 'root';
            $password = '';


            $db = new PDO($dsn, $user, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
           
            $req = $db->prepare("SELECT * FROM tailles WHERE volumeflacon=:volumeflacon");
            $req->bindValue(":volumeflacon", $value, PDO::PARAM_STR);
            $req->execute();
            $row = $req->rowCount();
            if($row == 1)
            {
                $data = $req->fetch();
                $req->closeCursor();
                $this->errors[$name_input][] = "Cette valeur existe déjà, veuillez en choisir une autre.";
            }
            else
            {
                $req->closeCursor();
                return false;
            }

            
    }

    public function uniqueOnCreateUtilisateur($name_input, $value, $rule)
        {
            $dsn = 'mysql:dbname=bottega;host=127.0.0.1;';
            $user = 'root';
            $password = '';


            $db = new PDO($dsn, $user, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
           
            $req = $db->prepare("SELECT * FROM utilisateurs WHERE email=:email");
            $req->bindValue(":email", $value, PDO::PARAM_STR);
            $req->execute();
            $row = $req->rowCount();
            if($row == 1)
            {
                $data = $req->fetch();
                $req->closeCursor();
                $this->errors[$name_input][] = "Cette valeur existe déjà, veuillez en choisir une autre.";
            }
            else
            {
                $req->closeCursor();
                return false;
            }

            
    }

    public function uniqueOnUpdateMarque($name_input, $value, $rule)
        {
            $dsn = 'mysql:dbname=bottega;host=127.0.0.1;';
            $user = 'root';
            $password = '';

            $db = new PDO($dsn, $user, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

            $req = $db->prepare("SELECT * FROM marques");
            $req->execute();
            $marques = $req->fetchAll();
            $req->closeCursor();

            foreach ($marques as $marque) 
            {
                if ($marque->id != $id) 
                {
                    if ($marque->nommarque == $value) 
                    {
                        $this->errors[$name_input][] = "Cette valeur existe déjà, veuillez en choisir une autre.";
                    }
                }
            }
        }

        public function uniqueOnUpdateGenre($name_input, $value, $rule)
        {
            $dsn = 'mysql:dbname=bottega;host=127.0.0.1;';
            $user = 'root';
            $password = '';

            $db = new PDO($dsn, $user, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

            $req = $db->prepare("SELECT * FROM genres");
            $req->execute();
            $genres = $req->fetchAll();
            $req->closeCursor();

            foreach ($genres as $genre) 
            {
                if ($genre->id != $id) 
                {
                    if ($genre->libellegenre == $value) 
                    {
                        $this->errors[$name_input][] = "Cette valeur existe déjà, veuillez en choisir une autre.";
                    }
                }
            }
        }

        public function uniqueOnUpdateTaille($name_input, $value, $rule)
        {
            $dsn = 'mysql:dbname=bottega;host=127.0.0.1;';
            $user = 'root';
            $password = '';

            $db = new PDO($dsn, $user, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

            $req = $db->prepare("SELECT * FROM tailles");
            $req->execute();
            $tailles = $req->fetchAll();
            $req->closeCursor();

            foreach ($tailles as $taille) 
            {
                if ($taille->id != $id) 
                {
                    if ($taille->volumeflacon == $value) 
                    {
                        $this->errors[$name_input][] = "Cette valeur existe déjà, veuillez en choisir une autre.";
                    }
                }
            }
        }
        public function uniqueOnUpdateUtilisateur($name_input, $value, $rule)
        {
            $dsn = 'mysql:dbname=bottega;host=127.0.0.1;';
            $user = 'root';
            $password = '';

            $db = new PDO($dsn, $user, $password);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);

            $req = $db->prepare("SELECT * FROM utilisateurs");
            $req->execute();
            $utilisateurs = $req->fetchAll();
            $req->closeCursor();

            foreach ($utilisateurs as $utilisateur) 
            {
                if ($utilisateur->id != $id) 
                {
                    if ($utilisateur->email == $value) 
                    {
                        $this->errors[$name_input][] = "Cette valeur existe déjà, veuillez en choisir une autre.";
                    }
                }
            }
        }
       
        public function min($name_input, $value, $rule) 
        { 
            //preg_match_all effectue une recherche globale sur toutes les occurrences du motif dans la chaîne.
            // \d Correspond à n’importe quel chiffre décimal. Équivalent à [0-9]
            preg_match_all("/\d+/", $rule, $matches);
            $minimum = intval($matches[0][0]);
            // var_dump($minimum); die();

            //mb_strlen retourne la taille d'une chaîne
            if (mb_strlen($value) < $minimum) 
            {
                $this->errors[$name_input][] = "Veuillez entrer au minimum " . $minimum . " caractères.";
            }
        }

        // elle retourne le tableau des erreurs
        public function getErrors()
        {
            return $this->errors;
        }

        //Cette fonction vérifie si le champs sur lequel il est appliqué est vide ou pas. 
        public function required($name_input, $value)
        {
            //trim supprime l'espace au début et à la fin du donnée envoyée
            $value = trim($value);
            if (!isset($value) || empty($value)) 
            {
                $this->errors[$name_input][] = "Ceci est obligatoire";
            }
        }

        public function integer($name_input, $value)
        {
            $value = trim($value);
            $value = intval($value);

            if (!$value)
            {
                $this->errors[$name_input][] = "Veuillez enter un entier";
            }
        }
    }