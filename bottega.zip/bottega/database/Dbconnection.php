<?php
namespace Database;
// PDO permet la connexion entre PHP et la base de données
use PDO;
// on crée une classe qui permet de faire des requêtes auprès de notre base de données
class Dbconnection{
// private parce qu'on veut utiliser la connection à l'intérieur de la classe Dbconnection
    private $dbname;
    private $host;
    private $username;
    private $password;
    //pour stocker notre instance PDO
    private $pdo;

    public function __construct(string $dbname, string $host, string $username, string $password){

        $this->dbname = $dbname;
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
    }
    // la méthode getPDO va retourner une instance de PDO pour faire des requêtes
    public function getPDO():PDO{
        // si pdo est null c'est à dire n'existe pas ,alors on instancie pdo
        if($this->pdo === null){
            //en se basant de la documentation officielle de php
            $this->pdo =new PDO ("mysql:dbname={$this->dbname}; host={$this->host}", $this->username, $this->password,
            //pour bien configurer notre pdo: juste après l'instanciation de PDO on va passer un tableau spécial:
            // on dit à notre pdo que tu nous lève des erreurs à chaque fois qu'il y a un souci 
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            // on veut que notre pdo récupère les données sous forme d'objets, si on la supprime on traite les données sous forme d'un tableau associatif et non sous forme d'objets.
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ]
        );
        }
        //et on le récupère et on le stocke dans $pdo
        return $this->pdo;
        
    }

}